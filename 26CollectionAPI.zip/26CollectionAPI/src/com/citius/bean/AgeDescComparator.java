package com.citius.bean;

 

import java.util.Comparator;

 

public class AgeDescComparator implements Comparator<Employee> {

 

    @Override
    public int compare(Employee o1, Employee o2) {
        if(o1.age<o2.age)
            return +1;
        if(o1.age>o2.age)
            return -1;
        return 0;
    }

 

}