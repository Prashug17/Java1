package com.citius.bean;

 

import java.util.Comparator;

 

public class GradeComparator implements Comparator<Employee> {

 

    @Override
    public int compare(Employee o1, Employee o2) {
        if(o1.grade<o2.grade)
            return 1;
        if(o1.grade>o2.grade)
            return -1;
        return 0;
    }

 

}