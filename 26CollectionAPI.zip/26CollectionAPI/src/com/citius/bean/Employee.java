package com.citius.bean;

public class Employee implements Comparable<Employee>{
	int id;
	String name;
	char grade;
	public double basicsalary;
	int age;
	
	

	public Employee(int id, String name, char grade, double basicsalary, int age) {
		super();
		this.id = id;
		this.name = name;
		this.grade = grade;
		this.basicsalary = basicsalary;
		this.age = age;
	}



	@Override
	public String toString() {
		return "\nEmployee [id=" + id + ", name=" + name + ", grade=" + grade + ", basicsalary=" + basicsalary + ", age="
				+ age + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		long temp;
		temp = Double.doubleToLongBits(basicsalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + grade;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (age != other.age)
			return false;
		if (Double.doubleToLongBits(basicsalary) != Double.doubleToLongBits(other.basicsalary))
			return false;
		if (grade != other.grade)
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}



//	@Override
//	public int compareTo(Employee o) {
//		if(this.id<o.id)
//			return -1;
//		if(this.id>o.id)
//			return 1;
//		return 0;
//	}

	@Override
	public int compareTo(Employee o) {
		if(this.basicsalary<o.basicsalary)
			return -1;
		if(this.basicsalary>o.basicsalary)
			return 1;
		return 0;
	}





	
	
	
	
	
}
