package com.citius.bean;

public class Student {
	String name;
	int mark1,mark2;
	public Student(String name, int mark1, int mark2) {
		super();
		this.name = name;
		this.mark1 = mark1;
		this.mark2 = mark2;
	}
	 
	public int getTotal() {
		return mark1+mark2;
	}

	


	@Override
	public String toString() {
		return "\nStudent [name=" + name + ", mark1=" + mark1 + ", mark2=" + mark2 + ", getTotal()=" + getTotal() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mark1;
		result = prime * result + mark2;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (mark1 != other.mark1)
			return false;
		if (mark2 != other.mark2)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	
	
	
}
