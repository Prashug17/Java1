package com.citius.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.citius.bean.AgeComparator;
import com.citius.bean.AgeDescComparator;
import com.citius.bean.Employee;
import com.citius.bean.GradeComparator;
import com.citius.bean.Student;
import com.citius.bean.TotalAscComparator;

public class Client2 {

	public static void main(String[] args) {
		Set<String> myset1=new HashSet<>();
		myset1.add("Embassy");
		myset1.add("Bangalore");
		myset1.add("Tech Village");
		myset1.add("Core Java");
		myset1.add("JDBC");
		myset1.add("Embassy");
		
		System.out.println(myset1);
		
		System.out.println(myset1.contains("Tech Village"));
		System.out.println(myset1.remove("Tech Village"));
		System.out.println(myset1.size());
		System.out.println(myset1.isEmpty());
		myset1.clear();
		System.out.println(myset1.isEmpty());
		
		for(String s:myset1) {
			System.out.println(s+":"+s.length());
		}
		
		Iterator<String> it1=myset1.iterator();
		while(it1.hasNext()) {
			String s=it1.next();
			System.out.println(s+":"+s.length());
		}
		
		System.out.println("_________________________________________");
		
//-------------------------------------------------------
		Set<Double> myset2=new TreeSet<>();
		myset2.add(10.0);
		myset2.add(11.0);
		myset2.add(12.0);
		myset2.add(13.0);
		myset2.add(14.0);
		myset2.add(15.0);
		
		System.out.println(myset2);
		
		System.out.println(myset2.contains(11.0));
		System.out.println(myset2.remove(11.0));
		System.out.println(myset2);
		System.out.println(myset2.size());
		System.out.println(myset2.isEmpty());
		myset2.clear();
		System.out.println(myset2.isEmpty());
		
//----------------------------------------------------------------
		AgeComparator ageComparator=new AgeComparator();
//		AgeDescComparator agedescComparator=new AgeDescComparator();
//		GradeComparator gradeComparator=new GradeComparator();
		Set<Employee> myset3=new TreeSet<>(ageComparator);
//		Set<Employee> myset3=new TreeSet<>(agedescComparator);
//		Set<Employee> myset3=new TreeSet<>(gradeComparator);
		
		Employee e1=new Employee(104,"Vinay", 'B',1200.00,24);
        Employee e2=new Employee(105,"Vandana", 'A',2400.00,28);
        Employee e3=new Employee(106,"Manvith", 'C',3000.00,30);
        Employee e4=new Employee(107,"Harshitha", 'A',3200.00,25);

        myset3.add(e1);
        myset3.add(e2);
        myset3.add(e3);
        myset3.add(e4);

        System.out.println(myset3);

        Employee dummy=new Employee(10,"Vandana", 'A',2400.00,28);
        System.out.println(myset3.contains(dummy));
        
        TotalAscComparator ascComparator=new TotalAscComparator();
        Set<Student> students=new TreeSet<>(ascComparator);
        //TotalDescComparator descComparator=new TotalDescComparator();
        //Set<Student> students=new TreeSet<>(descComparator);
        
        students.add(new Student("Vincent",80,82));
        students.add(new Student("Jason",40,64));
        students.add(new Student("Kapil",80,85));
        students.add(new Student("Kiran",60,82));
        
        System.out.println(students);
        
	
//        double sum=0;
//        for(Employee e:myset3) {
//        	sum+=e.basicsalary;
//        }
//        System.out.println(sum);
//--------------------------------------------------------------
//	AgeDescComparator agedescComparator=new AgeDescComparator();
//	Set<Employee> myset4=new TreeSet<>(agedescComparator);
//	
//	Employee e5=new Employee(104,"Vinay", 'B',1200.00,24);
//    Employee e6=new Employee(105,"Vandana", 'A',2400.00,28);
//    Employee e7=new Employee(106,"Manvith", 'C',3000.00,30);
//    Employee e8=new Employee(107,"Harshitha", 'A',3200.00,25);
//
//    myset3.add(e5);
//    myset3.add(e6);
//    myset3.add(e7);
//    myset3.add(e8);
//
//    System.out.println(myset3);
//
//    Employee dummy1=new Employee(10,"Vandana", 'A',2400.00,28);
//    System.out.println(myset3.contains(dummy1));
    
//------------------------------------------------------------------
    
    
	}

}


