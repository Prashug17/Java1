package com.citius.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.citius.bean.Sale;

public class Client4 {

	public static void main(String[] args) {
		Sale s1=new Sale("Bangalore","Jan",12000.00);
		Sale s2=new Sale("Mumbai","Mar",4000.00);
		Sale s3=new Sale("Bangalore","Apr",8000.00);
		Sale s4=new Sale("Delhi","Oct",16000.00);
		Sale s5=new Sale("Mumbai","Nov",24000.00);
		Sale s6=new Sale("Mumbai","Dec",36000.00);
		Sale s7=new Sale("Delhi","Mar",10000.00);
		Sale s8=new Sale("Bangalore","Apr",8000.00);
		
		List<Sale> salesDetails=new ArrayList<Sale>();
		salesDetails.add(s1); salesDetails.add(s2);
		salesDetails.add(s3); salesDetails.add(s4);
		salesDetails.add(s5); salesDetails.add(s6);
		salesDetails.add(s7); salesDetails.add(s8);
		
		System.out.println(salesDetails);
		
		Map<String, Double> citywiseSummaryMap=new TreeMap<>();
		for(Sale s:salesDetails) {
			if(citywiseSummaryMap.get(s.getCityName())==null) {
				citywiseSummaryMap.put(s.getCityName(),s.getSaleAmount());
			}else {
				citywiseSummaryMap.put(s.getCityName(), citywiseSummaryMap.get(s.getCityName())+s.getSaleAmount());
			}
		}
		
	    System.out.println(citywiseSummaryMap);
	    
	   System.out.println("----------------------------------");
	   
	   
	   Map<String, Double> monthwiseSummaryMap=new TreeMap<>();
		for(Sale s:salesDetails) {
			if(monthwiseSummaryMap.get(s.getMonth())==null) {
				monthwiseSummaryMap.put(s.getMonth(),s.getSaleAmount());
			}else {
				monthwiseSummaryMap.put(s.getMonth(), monthwiseSummaryMap.get(s.getMonth())+s.getSaleAmount());
			}
		}
	   
		System.out.println(monthwiseSummaryMap);
	}

}
