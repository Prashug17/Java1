package com.citius.ui;

 

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.citius.bean.Student;

 

public class Client1 {

 

    public static void main(String[] args) {

 

        Integer i1=new Integer(300);
        Integer i2=new Integer(40);
        Integer i3=new Integer(200);
        Integer i4=107;

        List<Integer> mylist=new ArrayList<>();
        //Collection<Integer> mylist=new ArrayList<>();
        
        mylist.add(i1);
        mylist.add(i2);
        mylist.add(i3);
        mylist.add(i4);
        mylist.add(new Integer(250));
        mylist.add(300);

        System.out.println(mylist);

        System.out.println(mylist.isEmpty());
        System.out.println(mylist.contains(250));
        System.out.println(mylist.contains(1000));
        mylist.remove(new Integer(250));
        System.out.println(mylist);
        System.out.println(mylist.indexOf(new Integer(300)));
        System.out.println(mylist.get(2));
        mylist.set(2, 400);
        System.out.println(mylist);
//        mylist.clear();
//        System.out.println(mylist.isEmpty());
        
        for(Integer i:mylist) {
        	System.out.println(i.doubleValue());
        }
        
        Iterator<Integer> it1=mylist.iterator();
        while(it1.hasNext()) {
        	Integer i=it1.next();
        	System.out.println(i.floatValue()); 	
        }
        System.out.println("-----------------------------------------");
        
//------------------
        String s1=new String("ab");
        String s2=new String("cd");
        String s3=new String("ef");
        String s4="ij";
        
        List<String> strList=new ArrayList<>();
        
        strList.add(s1);
        strList.add(s2);
        strList.add(s3);
        strList.add(s4);
        strList.add(new String("kl"));
        strList.add("300");
        
        System.out.println(strList);

        System.out.println(strList.isEmpty());
        System.out.println(strList.contains("cd"));
        System.out.println(strList.contains(1000));
        strList.remove("cd");
        System.out.println(strList);
        System.out.println(strList.indexOf("ef"));
        System.out.println(strList.indexOf(new String("xyz")));
        System.out.println(strList.get(2));
        strList.set(2, "400");
        System.out.println(strList);
        strList.clear();
        System.out.println(strList.isEmpty());
        
        for(String s:strList) {
        	System.out.println(s);
        }
        
        Iterator<String> st1 = strList.iterator();
        while(st1.hasNext()) {
            String j = st1.next();
            System.out.println(j.length());
        }
        System.out.println("-----------------------------------------");
    
//---------------------
        List<Student> StdList = new ArrayList<>();
        StdList.add(new Student("manvith",70,80));
        StdList.add(new Student("Raj",80,90));
        StdList.add(new Student("Ram",70,70));
        StdList.add(new Student("Sita",90,70));

        System.out.println(StdList);

        System.out.println("----------------------------------------");

 

        
        //System.out.println(StdList.isEmpty());
        //System.out.println(StdList.contains("manvith",70,80));

        System.out.println(StdList.indexOf(new Student("manvith",70,80)));

        System.out.println("----------------------------------------");

        Iterator<Student> std = StdList.iterator();
        while(std.hasNext()) {
            Student m= std.next();
            System.out.println(m.getTotal());
        }

        System.out.println("----------------------------------------");

         List list = new ArrayList();
         list.add(400);
         list.add("hello");
         list.add(new Student("manvith",40,70));
         list.add(new Double(90.0));

         System.out.println(list);

         System.out.println("----------------------------------------");

         for(Object o:list) {
             if(o instanceof Integer) {
                 Integer temp =(Integer)o;
                 System.out.println(temp.intValue());
             }

            if(o instanceof String) {
                String temp =(String)o;
                    System.out.println(temp.length());
                 }

            if(o instanceof Student) {
                Student temp =(Student)o;
                    System.out.println(temp.getTotal());
                 }

            if(o instanceof Double) {
                Double temp =(Double)o;
                    System.out.println(temp.intValue());
                 }
         }
         System.out.println("----------------------------------------");

         list.clear();
         System.out.println(list.isEmpty());

         System.out.println("----------------------------------------");

    }

}
