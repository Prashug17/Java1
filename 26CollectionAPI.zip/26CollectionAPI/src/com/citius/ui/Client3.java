package com.citius.ui;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.citius.bean.Student;

public class Client3 {

	public static void main(String[] args) {
		String s1="Country Name";
		String s2="Independence Year";
		String s3="Prime Minister";
		
		String s4="India";
		String s5="1947";
		String s6="Modi";
		
		Map<String,String> map=new TreeMap<>();
		map.put(s1, s4);
		map.put(s2, s5);
		map.put(s3, s6);
		
//		Map<String,String> map=new HashMap<>();
//		map.put(s1, s4);
//		map.put(s2, s5);
//		map.put(s3, s6);
		
		System.out.println(map);
		System.out.println(map.get("Country Name"));
		System.out.println(map.get("Prime Minister"));
		System.out.println(map.get("President"));
		
		Set<String> allKeys=map.keySet();
		for(String k:allKeys) {
			System.out.println(map.get(k));
		}
		
		Collection<String> allValues=map.values();
		for(String v:allValues) {
			System.out.println(v);
		}
		
		
		
//-----------------------------------------------------------
		Map<String, Student> studentMap;
		studentMap=new TreeMap<>();
		
		studentMap.put("Best", new Student("Victor", 99, 100));
		studentMap.put("Good", new Student("Nalini", 81, 86));
		studentMap.put("Average", new Student("John", 45, 50));
		
		System.out.println(studentMap.get("Best"));
		System.out.println(studentMap.get("Average"));
		
		Set<String> allKeyss=studentMap.keySet();
		for(String k:allKeyss) {
			System.out.println(studentMap.get(k));
		}
		
	}

}
