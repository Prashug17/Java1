package pack3;

import java.util.function.Consumer;

public class ConsumerClient {
	
	static void demo1(Consumer<Integer> c) {
		c.accept(600);
	}

	public static void main(String[] args) {
		Consumer<String> c1=(String s)-> System.out.println(s.toUpperCase());
			c1.accept("hello");
			
	System.out.println("--------------------------------");
			
	Consumer<Integer> c2=(i)->{
		System.out.println(i.intValue());
		System.out.println(i.doubleValue());
	};
	c2.accept(500);	
	
	demo1(c2);
	
	System.out.println("--------------------------------");
	
	demo1((n)->{
		System.out.println(n.floatValue());
		System.out.println(n.doubleValue());
	});
	
	System.out.println("--------------------------------");
	
	demo1((a)->{
		System.out.println(a.longValue());
		System.out.println(a.doubleValue());
	});
	
	System.out.println("--------------------------------");
	
	Consumer<Student> c4=(s)-> {
			System.out.println(s.getTotal());
	};
	
	Student s=new Student("Ram",80,70);
	c4.accept(s);
	
	System.out.println("--------------------------------");
	
	Consumer<Circle> c5=(c)-> {
		System.out.println(c.getArea());
};

Circle c=new Circle(70);
c5.accept(c);
	
	
		}

	}


