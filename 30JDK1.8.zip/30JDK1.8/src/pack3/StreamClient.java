package pack3;

public class StreamClient {

	public static void main(String[] args) {
		

	}

}
