package pack3;

import java.util.function.Predicate;

public class PredicateClient {

	public static void main(String[] args) {
		Predicate<String> p1;
//		p1=(s)-> {return s.length()>10;};
		p1=(s)-> s.length()>10;
		
		System.out.println(p1.test("Hello How are you?"));
		System.out.println(p1.test("Hello"));
		
		System.out.println("--------------------------------");
//		Predicate<Integer>p2;
//		p2=(i)->{
//			if((i/100)>=1) {
//				return true;
//			}
//			return false;
//		};
		
		Predicate<Integer>p2;
		p2=(i)->i%100==0;
		
		System.out.println(p2.test(200));
		
		System.out.println("--------------------------------");
		
		Predicate<Student> p3;
		p3=(s)-> s.getTotal()>100;
		
		Student s=new Student("Ram",80,70);
		System.out.println(p3.test(s));
		
		Student s1=new Student("Sam",10,20);
		System.out.println(p3.test(s1));
		
		System.out.println("--------------------------------");
		
		Predicate<Circle> c2;
		
		c2=(c)-> c.getArea()>100;
		Circle c=new Circle(10);
		System.out.println(c2.test(c));
	}

}
