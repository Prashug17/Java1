package pack3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FunctionClient {

	public static void main(String[] args) {
		Function<Circle,Double> f1;
		
		f1=(c)->c.computeArea();
			
		Circle c=new Circle(10);
		Double d=f1.apply(c);
		System.out.println(d);
		
		System.out.println("--------------------------------");
		
		Function<Student, Integer> f2;
		f2=(s)->s.getTotal();
		Student s=new Student("Rahul",80,90);
		System.out.println("--------------------------------");
		
		Integer total=f2.apply(s);
		System.out.println(total);
		
		System.out.println("--------------------------------");
		
		Collection<String> cities=new ArrayList<String>();
		cities.add("Delhi");
		cities.add("Pune");
		cities.add("Mumbai");
		cities.add("Hyderabad");
		cities.add("Cochin");
		
		cities.forEach((e)->{
			System.out.println(e);
		});
		
		cities.forEach((e)->{
			System.out.println(e.length());
		});
		
		cities.forEach((e)->{
			System.out.println(e.toUpperCase());
		});
		
		System.out.println("--------------------------------");
		
		Collection<Circle> circles=new HashSet<>();
		circles.add(new Circle(90));
		circles.add(new Circle(100));
		circles.add(new Circle(10));
		circles.add(new Circle(40));
		
		circles.forEach((e)->
		System.out.println(e.getArea()));
		
		System.out.println("--------------------------------");
		
		Stream<Circle> stream1=circles.stream();
		stream1.forEach((a)->System.out.println(a));
		
		System.out.println("--------------------------------");
		
		Stream<Circle> stream2=circles.stream();
	stream2.filter((e)->e.getRadius()>50).forEach((a)->System.out.println(a));
	
	System.out.println("--------------------------------");
	
	Stream<Circle> stream3=circles.stream();
	stream3.filter((e)->e.getRadius()>50).sorted().forEach((a)->System.out.println(a));
	
	System.out.println("--------------------------------");
	
	Collection employees = new ArrayList<>();

    employees.add(new Employee(101,"manvith",'A',40000));
    employees.add(new Employee(102,"gagan",'B',20000));
    employees.add(new Employee(103,"raj",'B',25000));
    employees.add(new Employee(104,"smith",'C',10000));
    employees.add(new Employee(105,"pavan",'A',45000));


    Stream <Employee> st = employees.stream();
    st.sorted().forEach((a)->System.out.println(a));
    
    System.out.println("--------------------------------");
    
    Stream <Employee> st1 = employees.stream();
    st1.sorted().filter((e)->e.getBasicSalary()>5000).forEach((e)->System.out.println(e));
    
    System.out.println("--------------------------------");
    
    Stream <Employee> st2 = employees.stream();
//    st.sorted(new salaryComparator()).forEach((e)->System.out.println(e));
    
    System.out.println("--------------------------------");
    
    
//    List<Employee>emp1=st.sorted(new salaryComparator()).collect(Collectors.toList());
//    System.out.println(emp1);
    
    System.out.println("--------------------------------");
    
    Stream <Employee> str3 = employees.stream();
    
    Optional<Employee> search=st2.parallel().filter((e)->e.getGrade()=='A').findAny();
    if(search.isPresent()) {
        System.out.println(search.get());
    }
    
    System.out.println("--------------------------------");
    
    Stream<Employee> st4=employees.stream();
    List<String> allNames=st4.map((e)->e.getName()).collect(Collectors.toList());
    System.out.println(allNames);
    
    System.out.println("--------------------------------");
    
    Stream<Employee> st5=employees.stream();
    List<Double> salary =st5.map((e)->e.getBasicSalary()).collect(Collectors.toList());
    System.out.println(salary);
    
	}
}


