package pack1;

public interface A {
	public static void m1() {
		System.out.println("m1");
	}
	
	default void m2() {
		System.out.println("m2 in A");
	
	}
	
	void m3(); 
}
