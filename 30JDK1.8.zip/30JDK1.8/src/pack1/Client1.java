package pack1;
public class Client1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A ref=new B();
		ref.m2();
		ref.m3();
		A.m1();

	}

}
