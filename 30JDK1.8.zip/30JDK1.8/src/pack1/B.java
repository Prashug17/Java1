package pack1;
public class B implements A {

	@Override
	public void m3() {
		System.out.println("m3 in B");
		
	}
	
	@Override
	public void m2() {
		System.out.println("m2 in B");
		
	}
	
}
