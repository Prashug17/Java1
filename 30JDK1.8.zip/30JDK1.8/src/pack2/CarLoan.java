package pack2;

public class CarLoan implements Loan {

	@Override
	public double getInterestRate() {
		// TODO Auto-generated method stub
		return 0.15;
	}

}
