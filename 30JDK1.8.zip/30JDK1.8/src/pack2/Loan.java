package pack2;

@FunctionalInterface
public interface Loan {
	double getInterestRate();
	
	
}
