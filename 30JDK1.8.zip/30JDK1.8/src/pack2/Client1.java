package pack2;

public class Client1 {
	
	static void print(Loan loan) {
		System.out.println(loan.getInterestRate());
	}

	public static void main(String[] args) {
		Loan loan;
		loan =new Loan() {
			
			@Override
			public double getInterestRate() {
				// TODO Auto-generated method stub
				return 0.20;
			}
		};
//		System.out.println(loan.getInterestRate());
		print(loan);
		
		loan =new Loan() {
			
			@Override
			public double getInterestRate() {
				// TODO Auto-generated method stub
				return 0.35;
			}
		};
		print(loan);
//		System.out.println(loan.getInterestRate());
		
		loan=()->{
			return(0.87);
		};
		
		print(loan);
		
		loan=()->{
			return(0.50);
		};
		
		print(loan);
		
		loan=()-> 0.90;//if 1 statements is there curly braces is optional
		print(loan);
		
	}
}
		

