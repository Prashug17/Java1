package pack2;

public interface NumberProcessor {
	void process(Integer i);
}
