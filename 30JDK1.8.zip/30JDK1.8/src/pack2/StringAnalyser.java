package pack2;

@FunctionalInterface
public interface StringAnalyser {
	boolean test(String s);
	

}
