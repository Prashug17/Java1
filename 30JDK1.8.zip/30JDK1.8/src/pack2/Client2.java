package pack2;

public class Client2 {

	public static void main(String[] args) {
		StringAnalyser sal=new StringAnalyser() {
			
			@Override
			public boolean test(String s) {
				String data="Hello";
				
				if(s.contains(data))
					return true;
				else
					return false;
			}
		};
		System.out.println(sal.test("Hello How are you"));
		
		StringAnalyser sa2=(String s)->{
			if(s.contains("ETV"))
				return true;
			else
				return false;
		};
		
		System.out.println(sa2.test("Welcome to ETV Bangalore"));
		
		StringAnalyser sa3=(s)->s.contains("ETV");
		System.out.println(sa3.test("Welcome to ETV Bangalore"));
		
		
		StringAnalyser sa4=(s)->s.startsWith("Welcome");
		System.out.println(sa4.test("Welcome to ETV BAngalore"));
		
	}

}
