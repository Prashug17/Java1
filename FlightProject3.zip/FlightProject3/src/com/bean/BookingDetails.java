package com.bean;

public class BookingDetails {
	private int booking_id; 
	private int customer_id;
	private int flight_id;
	private float booking_amount;
	private int seat_number;
	
	public BookingDetails() {
		super();
	}

	public BookingDetails(int booking_id, int customer_id, int flight_id, float booking_amount, int seat_number) {
		super();
		this.booking_id = booking_id;
		this.customer_id = customer_id;
		this.flight_id = flight_id;
		this.booking_amount = booking_amount;
		this.seat_number = seat_number;
	}

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public int getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}

	public float getBooking_amount() {
		return booking_amount;
	}

	public void setBooking_amount(float booking_amount) {
		this.booking_amount = booking_amount;
	}

	public int getSeat_number() {
		return seat_number;
	}

	public void setSeat_number(int seat_number) {
		this.seat_number = seat_number;
	}

	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", customer_id=" + customer_id + ", flight_id=" + flight_id
				+ ", booking_amount=" + booking_amount + ", seat_number=" + seat_number + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(booking_amount);
		result = prime * result + booking_id;
		result = prime * result + customer_id;
		result = prime * result + flight_id;
		result = prime * result + seat_number;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingDetails other = (BookingDetails) obj;
		if (Float.floatToIntBits(booking_amount) != Float.floatToIntBits(other.booking_amount))
			return false;
		if (booking_id != other.booking_id)
			return false;
		if (customer_id != other.customer_id)
			return false;
		if (flight_id != other.flight_id)
			return false;
		if (seat_number != other.seat_number)
			return false;
		return true;
	}
	
	
	
}
