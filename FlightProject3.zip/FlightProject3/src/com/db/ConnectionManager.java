package com.db;

 

import java.sql.Connection;
import java.sql.DriverManager;

 

public class ConnectionManager {

    public static Connection createConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

             String url="jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=Flight1;trustServerCertificate=true;";
             Connection con=DriverManager.getConnection(url, "sa", "password_123");
             return con;
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public static void closeConnection(Connection con) {
    	try {
    		con.close();
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    }
	
}
