package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.bean.BookingDetails;
import com.bean.Customer;
import com.bean.Flight;
import com.ui.CustomerInterface;



public class CustomerDaoImpl implements CustomerDao{
	static int flitid;
	static float price;
	
	@Override
	public boolean addCustomer(Connection con , Customer customer) {
		boolean result = false;
		try {
			PreparedStatement st=con.prepareStatement(INSERT_SQL1);

			st.setInt(1, customer.getCustomer_id());
			st.setString(2, customer.getCustomer_name());
			st.setString(3, customer.getCustomer_username());
			st.setString(4, customer.getCustomer_password());
			st.setString(5, customer.getCustomer_email());
			st.setString(6, customer.getCustom_phone());


			int r = st.executeUpdate();
			if (r == 1) {
				result = true;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	
	
	@Override
	public boolean updateCustomer(Connection con, int customer_id, String choice, String columnName) {
		
		boolean result = false;

		String query = "update Customer set " + columnName + " = ? where customer_id = (?)";
		try {
			PreparedStatement st=con.prepareStatement(query);
			st.setString(1, choice);
			st.setInt(2, customer_id);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	
	@Override
	public boolean deleteCustomer(Connection con, int customer) {
		boolean result = false;

		try {
			PreparedStatement st=con.prepareStatement(DELETE_SQL1);
			st.setInt(1, customer);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	
	@Override
	public Customer getCustomer(Connection con, int customer) {
		Customer output = new Customer();
		try {
			PreparedStatement st=con.prepareStatement(GET_SQL);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Customer output1 = new Customer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6));
				output=output1;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return output;
	}

	@Override
	public void addFlight(Connection con , Flight flight) {
		
		try {
			PreparedStatement st=con.prepareStatement(INSERT_SQL2);

			st.setString(1, flight.getFlight_date());
			st.setString(2, flight.getFlight_source());
			st.setString(3, flight.getFlight_destination());

			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				flitid=rs.getInt(1);
				price=rs.getFloat(6);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			PreparedStatement st1=con.prepareStatement(INSERT_SQL3);
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter your customer id:");
			int cust_id=scanner.nextInt();
			System.out.println("Enter your seat number:");
			int seat=scanner.nextInt();
				
			st1.setInt(1, cust_id);
			st1.setInt(2, flitid);
			st1.setFloat(3,price);
			st1.setInt(4, seat);
			
			st1.executeUpdate();
			
			CustomerInterface ai = new CustomerInterface();
			ai.interfaceHandler();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("Flight booked successfully");
	}

	@Override
	public boolean deleteFlight(Connection con , int flight) {
		boolean result = false;

		try {
			PreparedStatement st=con.prepareStatement(DELETE_SQL);
			st.setInt(1, flight);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean updateFlight(Connection con , int flight_id , String choice ,String columnName ) {
		
		boolean result = false;

		String query = "update Flight set " + columnName + " = ? where flight_id = (?)";
		try {
			PreparedStatement st=con.prepareStatement(query);
			st.setString(1, choice);
			st.setInt(2, flight_id);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}
	
	public Flight getFlight(Connection con) {
		Flight output =new  Flight();
		try {
			PreparedStatement st=con.prepareStatement(GET_ALL_SQL);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Flight flight = new Flight(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getFloat(6), rs.getFloat(7), rs.getInt(8));
				output=flight;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return output;
	}
	
	public List<Customer> getAllCustomers(Connection con) {


		List<Customer> ls = new ArrayList<Customer>();
		List<Customer> output = new ArrayList<Customer>();
		try {
			PreparedStatement st=con.prepareStatement(GET_ALL_SQL1);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Customer customer = new Customer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6));
				output.add(customer);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return output;
	}
	
	@Override
	public List<BookingDetails> bookingDetails(Connection con , int id) {
		BookingDetails book=new BookingDetails();
		List<BookingDetails> bookList = new ArrayList<BookingDetails>();
		
		try {
			PreparedStatement st=con.prepareStatement(sql);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				book.setBooking_id(rs.getInt(1));
				book.setCustomer_id(rs.getInt(2));
				book.setFlight_id(rs.getInt(3));
				book.setBooking_amount(rs.getFloat(4));
				book.setSeat_number(rs.getInt(5));
				bookList.add(book);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return bookList;
	}
	
}
