package com.ui;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class AdminCredential extends credentials{
	
	public  void credentialCheck() throws SQLException {

		
		java.sql.Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Admin");
		
	
		System.out.println("enter id");
		id = scan.nextInt();
		
		System.out.println("enter username");
		 name = scan.next();
		 
		System.out.println("enter password");
		 pass = scan.next();
		
		while(rs.next()) {
			
			int admin_id = rs.getInt("admin_id");
			String username =rs.getString("name");	
			String password =rs.getString("password");
			
			
			if(admin_id == id && username.equals(name)  && password.equals(pass)) {
				AdminInterface admin = new AdminInterface();
				admin.interfaceHandler();
			}
			
		}
		System.out.println("invalid credential");
		credentialCheck();
		
	}
	

}
