package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;


public class AddFlightActionCustomer extends Action
{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Flight");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Flight flt = new Flight();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter date");
		flt.setFlight_date(sc.next());
		System.out.println("Enter source");
		flt.setFlight_source(sc.next());
		System.out.println("Enter destination");
		flt.setFlight_destination(sc.next());
		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		
		impl.addFlight(con, flt);
			
		
	}

}
