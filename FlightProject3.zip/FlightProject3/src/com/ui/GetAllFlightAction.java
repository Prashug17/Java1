package com.ui;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.FlightDaoImpl;



public class GetAllFlightAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Displaying all the flights");
		System.out.println("----------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Connection con = ConnectionManager.createConnection();
		FlightDaoImpl impl = new FlightDaoImpl();
		
		List<Flight> output = impl.getAllFlights(con); 
		AdminInterface ad = new AdminInterface();
//		for(Flight i:output) {
//			System.out.println(i.getFlight_id()+" "+ i.getFlight_name()+" "+i.getFlight_source()+" "+i.getFlight_destination());
//		}
//		
		Iterator<Flight> itr=output.iterator();
		while(itr.hasNext()) {
			Flight flight=itr.next();
			System.out.println(flight.getFlight_name());
		}
		
		
		System.out.println("press 0 to go back");
		if(sc.nextInt() == 0) {
			ad.interfaceHandler();
		}
	}

}
