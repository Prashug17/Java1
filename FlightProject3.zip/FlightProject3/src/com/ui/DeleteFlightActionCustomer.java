package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;



public class DeleteFlightActionCustomer extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Cancelling ticket booking");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Booking Id to cancel booking");
		int id = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		CustomerInterface ad = new CustomerInterface();
		
		if (impl.deleteFlight(con, id) == true) {
			System.out.println("Flight deleted");
			ad.interfaceHandler();
		}
		
		else {
			System.out.println("Ticket not cancelled");
			ad.interfaceHandler();
		}
	}

}
