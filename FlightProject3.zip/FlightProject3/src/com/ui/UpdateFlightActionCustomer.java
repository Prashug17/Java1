package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;


public class UpdateFlightActionCustomer extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Updating Ticket details");
		System.out.println("------------------------");
		
	}
	
	
	void display() {
		System.out.println( "1. Date\n" + "0. exit");
	}

	@Override
	public void execute() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the flight id to be update details");
		int id = sc.nextInt();
		display();
		System.out.println("enter the choice,That you want to update");
		int choice = sc.nextInt();
		String update = null ;
		String columnName = null;
		CustomerInterface ad = new CustomerInterface();
		
		switch(choice) {
		case 1: System.out.println("Enter date");
		update = sc.next();
		columnName = "flight_date";
		break;
				
		case 0 :ad.interfaceHandler();
				break;
				
		default: System.out.println("invalid choice");
		}

		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		
		
		if(impl.updateFlight(con, id,update,columnName) ==  true) {
			System.out.println("Flight ticket details updated");
			ad.interfaceHandler();
		}
		else {
			System.out.println("Details not updated");
		}
	}

}
