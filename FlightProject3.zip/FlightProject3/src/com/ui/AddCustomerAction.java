package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.bean.Customer;
import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;

public class AddCustomerAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Customer");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Customer cst = new Customer();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Customer id");
		cst.setCustomer_id(sc.nextInt());
		System.out.println("Enter Customer name");
		cst.setCustomer_name(sc.next());
		System.out.println("Enter username");
		cst.setCustomer_username(sc.next());
		System.out.println("Enter password");
		cst.setCustomer_password(sc.next());
		System.out.println("Enter email");
		cst.setCustomer_email(sc.next());
		System.out.println("Enter Phone number");
		cst.setCustom_phone(sc.next());
		
		int id=cst.getCustomer_id();
		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		CustomerInterface ai = new CustomerInterface();
		
		if (impl.addCustomer(con, cst) == true) {
//			impl.insertId(con, id);
			System.out.println("Customer added");
			ai.interfaceHandler();
		}
		
		else {
			System.out.println("Customer not added");
			ai.interfaceHandler();
		}
	}
}
