package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.FlightDaoImpl;

public class AddFlightAction extends Action
{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Flight");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Flight flt = new Flight();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter flight id");
		flt.setFlight_id(sc.nextInt());
		System.out.println("Enter flight name");
		flt.setFlight_name(sc.next());
		System.out.println("Enter date");
		flt.setFlight_date(sc.next());
		System.out.println("Enter source");
		flt.setFlight_source(sc.next());
		System.out.println("Enter destination");
		flt.setFlight_destination(sc.next());
		System.out.println("Enter price");
		flt.setFlight_price(sc.nextFloat());
		System.out.println("Enter duration");
		flt.setFlight_duration(sc.nextFloat());
		System.out.println("Enter seat capacity");
		flt.setFlight_capacity(sc.nextInt());
		
		Connection con = ConnectionManager.createConnection();
		FlightDaoImpl impl = new FlightDaoImpl();
		AdminInterface ai = new AdminInterface();
		
		if (impl.addFlight(con, flt) == true) {
			System.out.println("Flight Table Created");
			ai.interfaceHandler();
		}
		
		else {
			System.out.println("Flight Table not created");
			ai.interfaceHandler();
		}
	}

}
