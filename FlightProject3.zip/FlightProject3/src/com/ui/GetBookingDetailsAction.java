package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;



public class GetBookingDetailsAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Getting booking details");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Booking Id to get booking details");
		int id = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		CustomerInterface ad = new CustomerInterface();
		
		System.out.println(impl.bookingDetails(con, id));
		ConnectionManager.closeConnection(con);
		ad.interfaceHandler();
	}

}
