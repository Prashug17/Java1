//program to count the number of legs of animals
package Coding01;

import java.util.Scanner;

public class Code1 {
	public int CountLegs(int a,int b,int c){
		int count=(a*2)+(b*4)+(c*4);
		return count;
	}
	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the number of chickens");
		int a=scan.nextInt();
		System.out.println("Enter the number of cows");
		int b=scan.nextInt();
		System.out.println("Enter the number of pigs");
		int c=scan.nextInt();
		
		Code1 count=new Code1();
		System.out.println(count.CountLegs(a, b, c));
	}

}
