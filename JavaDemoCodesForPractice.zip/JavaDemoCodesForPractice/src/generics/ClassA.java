package generics;

public class ClassA<T extends Number> {
	T n1;
	T n2;

	public ClassA(T n1, T n2) {
		super();
		this.n1 = n1;
		this.n2 = n2;
	}

	public double add() {

		return  n1.doubleValue() + n2.doubleValue();
	}

	public T sub() {

		return (T) (Object) (n1.doubleValue() - n2.doubleValue());
	}

	public T mul() {

		return (T) (Object) (n1.doubleValue() * n2.doubleValue());
	}

	public T div() {

		return (T) (Object) (n1.doubleValue() / n2.doubleValue());
	}

}
