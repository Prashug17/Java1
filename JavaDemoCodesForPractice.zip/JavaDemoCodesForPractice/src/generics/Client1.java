package generics;

public class Client1 {

	public static void main(String[] args) {
		ClassA<Integer> num=new ClassA(8,4);
		System.out.println(num.add());
		System.out.println(num.sub());
		System.out.println(num.mul());
		System.out.println(num.div());
		

		ClassB<Integer> nums=new ClassB(12,6);
		System.out.println(nums.add());
		
	}

}
