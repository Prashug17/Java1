package Exception;

public class ExceptionHandle extends Exception {

	String exp;

	public ExceptionHandle(String exp) {
		super(exp);
	}
	
}
