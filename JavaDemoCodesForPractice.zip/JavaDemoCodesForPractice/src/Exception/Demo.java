package Exception;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		System.out.println("Enter your age:");
		Scanner scanner=new Scanner(System.in);
		int age=scanner.nextInt();
		TestClass test = new TestClass();
		try {
			test.Validate(age);
		} catch (ExceptionHandle e) {
			
			System.out.println(e);
		}
	}

}
