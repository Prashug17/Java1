package Demo02;

public class SwapCharactersInString {

	public static void swap(String str,int index1,int index2) {
		char[] ch=str.toCharArray();
		char temp=ch[index1];
		ch[index1]=ch[index2];
		ch[index2]=temp;
		
		StringBuilder sb=new StringBuilder();
		for(char c:ch) {
			sb.append(c);
		}
		
		String str1=sb.toString();
		System.out.println(str1);
	}
	public static void main(String[] args) {
		String name="Welcome";
		SwapCharactersInString.swap(name, 1, 2);
	}
}
