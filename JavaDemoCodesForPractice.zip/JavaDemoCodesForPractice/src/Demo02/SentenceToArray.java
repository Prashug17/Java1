package Demo02;

import java.util.Arrays;

public class SentenceToArray {

	public static void main(String[] args) {
		String sentence="Java is a programming language";
		String[] array=sentence.split(" ");
		
		System.out.println(Arrays.toString(array));
		for(String str:array) {
			System.out.println(str);
		}
		
		String[] arr=sentence.split("a");
		System.out.println(Arrays.toString(arr));

	}

}
