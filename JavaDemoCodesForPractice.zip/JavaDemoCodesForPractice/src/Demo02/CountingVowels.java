package Demo02;

public class CountingVowels {

	public static void main(String[] args) {
		String name="Citiustech";
		String name1=name.toLowerCase();
		
		char[] ch=name1.toCharArray();
		int count=0;
		for(char a:ch) {
			if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u') {
				count++;
				System.out.println(a);
			}
		}
		System.out.println("The number of vowels are:"+count);
	}
}
