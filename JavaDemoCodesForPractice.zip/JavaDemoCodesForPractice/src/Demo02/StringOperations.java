package Demo02;

import java.util.Arrays;

public class StringOperations {

	public static void main(String[] args) {
		String name="Hello welcome home!";
		String name1="buddy";
		System.out.println(name.length());
		System.out.println(name.toLowerCase());
		System.out.println(name.toUpperCase());
		System.out.println(name.charAt(6));
		System.out.println(name.contains("ho"));
		System.out.println(name.concat("Lets start!"));
		System.out.println(name.concat(name1));
		System.out.println(name.compareTo(name1));
		System.out.println(name.equals(name1));
		System.out.println(name.endsWith("me!"));
		System.out.println(name.indexOf("o"));
		System.out.println(name.indexOf("com"));
		System.out.println(name.isEmpty());
		System.out.println(name.lastIndexOf("o"));
		System.out.println(name.replace("o", "w"));
		System.out.println(name.replace("home", "world"));
		System.out.println(name.startsWith("Hel"));
		System.out.println(name.substring(6,13));
		
		char[] ch=name.toCharArray();
		System.out.println(Arrays.toString(ch));
	}

}
