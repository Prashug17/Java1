package Demo02;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class RemoveDuplicatesFromArray {
	public static void main(String[] args) {
		Integer[] arr= {10,20,20,30,40,40,50,50,60};
		Set<Integer> set=new TreeSet<>(Arrays.asList(arr));
		System.out.println(set);
		Integer[] array=new Integer[set.size()];
		set.toArray(array);
		System.out.println(Arrays.toString(array));
	}
}
