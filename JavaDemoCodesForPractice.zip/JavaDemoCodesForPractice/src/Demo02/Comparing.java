package Demo02;

public class Comparing {

	public static void main(String[] args) {
	String s1="hello";
	String s2="hello";
	String s3="hellooo";
	System.out.println(s1.compareTo(s2));
	System.out.println(s1.compareTo(s3));
	System.out.println(s3.compareTo(s2));
	
	System.out.println("--------------------");
	String s4=new String("hello");
	String s5=new String("hello");
	System.out.println(s4==s5);
	System.out.println(s4.equals(s5));

	}

}
