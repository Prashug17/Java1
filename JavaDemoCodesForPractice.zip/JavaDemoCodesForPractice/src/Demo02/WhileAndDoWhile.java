package Demo02;

public class WhileAndDoWhile {

	public static void main(String[] args) {
		int i=1;
		while(i<=5) {
			System.out.println("This is While"+i);
			i++;
		}
		
		//doWhile executes the block once even the condition is false
		int j=5;
		do {
			System.out.println("This is doWhile"+j);
			j++;
		}
		while(j<4);
	}

}
