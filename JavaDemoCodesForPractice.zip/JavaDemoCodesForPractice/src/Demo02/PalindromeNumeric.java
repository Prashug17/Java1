package Demo02;

import java.util.Scanner;

public class PalindromeNumeric {

	public static void main(String[] args) {
		System.out.println("Enter a number");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();
		int original=num;
		int reverse=0,reminder=0;
		
		while(num!=0) {
			reminder=num%10;
			reverse=reverse*10+reminder;
			num=num/10;
		}
		System.out.println(reverse);
		if(original==reverse) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
	}

}
