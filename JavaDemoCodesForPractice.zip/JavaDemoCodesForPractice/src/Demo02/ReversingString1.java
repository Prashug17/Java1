package Demo02;

import java.util.Scanner;

public class ReversingString1 {

	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner scan=new Scanner(System.in);
		String name=scan.next();
		
		char[] ch=name.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			System.out.print(ch[i]);
		}
	}
}
