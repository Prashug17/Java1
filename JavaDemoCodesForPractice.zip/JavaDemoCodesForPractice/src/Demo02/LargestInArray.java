package Demo02;

public class LargestInArray {

	public static void main(String[] args) {
		int[] arr= {10,23,60,11,25,44,50};
		int max=arr[0];
		for(int a:arr) {
			if(a>max)
				max=a;
		}
		System.out.println("Largest number is:"+max);
	}

}
