package Demo02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortingArray {

	public static void main(String[] args) {
		Integer[] array= {30,20,40,50,10,60};
		Arrays.sort(array);
		System.out.println(Arrays.toString(array));
//		List<Integer> list=Arrays.asList(array);
//		System.out.println(list);
//		Collections.sort(list);
//		System.out.println(list);
//		Integer[] array1=new Integer[list.size()];
//		list.toArray(array1);
//		for(int i:array1) {
//			System.out.print(i+" ");
//		}
	}
}
