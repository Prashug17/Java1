package Demo02;

import java.util.Scanner;

public class ConcatinationOfString {

	public static void main(String[] args) {
		System.out.println("Enter the String1");
		Scanner scanner=new Scanner(System.in);
		String string1=scanner.next();
		System.out.println("Enter the String2");
		String string2=scanner.next();
		System.out.println("Concatinated string is:"+string1+string2);
		System.out.println("Concatinated string is:"+string1.concat(string2));
	}

}
