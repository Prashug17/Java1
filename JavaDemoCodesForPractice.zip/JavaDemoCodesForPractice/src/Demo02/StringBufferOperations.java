package Demo02;

public class StringBufferOperations {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("Java");
		System.out.println(sb);
		System.out.println("-------------------");
		
		sb.append(" language");
		System.out.println(sb);
		System.out.println("-------------------");
		
		sb.insert(13,"!!!");
		System.out.println(sb);
		System.out.println("-------------------");
		
		sb.replace(0, 4, "Python");
		System.out.println(sb);
		System.out.println("-------------------");
		
		System.out.println(sb.substring(2, 6));
		System.out.println("-------------------");
		
		System.out.println(sb.reverse());
		System.out.println("-------------------");
		
		sb.reverse();
		
		sb.delete(15, 18);
		System.out.println(sb);
		System.out.println("-------------------");
		
		String name="Hello";
		StringBuffer sbf=new StringBuffer(name);
		sbf.reverse();
		String name1=sbf.toString();
		System.out.println(name1);
		System.out.println("-------------------");
		
		System.out.println(sb.charAt(3));
		System.out.println(sb.indexOf("th"));
		System.out.println(sb.length());
		System.out.println(sb.deleteCharAt(14));
		
		
	}

}
