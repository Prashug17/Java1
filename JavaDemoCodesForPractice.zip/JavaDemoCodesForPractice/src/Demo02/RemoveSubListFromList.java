package Demo02;

import java.util.ArrayList;
import java.util.List;

public class RemoveSubListFromList {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("abc");
		list.add("def");
		list.add("ijk");
		list.add("lmn");
		list.add("opq");
		System.out.println("Original List: "+list);
		//sublist will remove elements in the give range and clear to clear those elements 
		list.subList(1, 3).clear();
		System.out.println("Sub List:"+list);
	}

}
