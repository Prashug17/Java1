package Demo02;

public class equalsMethod {

	public static void main(String[] args) {
		
		Integer a=10;
		Integer b=10;
		System.out.println(a.equals(b));

	}

}
