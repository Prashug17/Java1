package Demo02;

public class PrintEvenAndOddNumbers {

	public static void main(String[] args) {
		System.out.println("Printing even numbers");
		for(int i=2;i<=10;i=i+2) {
			System.out.println(i);
		}
		
		System.out.println("Printing odd numbers");
		for(int j=1;j<=10;j++) {
			if(j%2!=0) {
				System.out.println(j);
			}
		}
		
	}

}
