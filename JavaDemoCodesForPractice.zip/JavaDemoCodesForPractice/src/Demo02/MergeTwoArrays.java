package Demo02;

import java.util.Arrays;

public class MergeTwoArrays {

	public static void main(String[] args) {
		int[] arr1= {10,60,25,44};
		int[] arr2= {51,22,34,30};
		int l1=arr1.length;
		int l2=arr2.length;
		int[] arr3=new int[l1+l2];
		int i=0;
		for(int a:arr1) {
			arr3[i]=a;
			i++;
		}
		
		for(int b:arr2) {
			arr3[i]=b;
			i++;
		}
		System.out.println("Merged array:"+Arrays.toString(arr3));
		Arrays.sort(arr3);
		System.out.println("Sorted array:"+Arrays.toString(arr3));
	}
}
