package Demo02;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		int factorial=1;
		System.out.println("Enter a number");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();
		
		for(int i=1;i<=num;i++) {
			factorial=factorial*i;
		}
		System.out.println(factorial);
	}
}
