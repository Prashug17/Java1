package Demo02;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		System.out.println("Enter digit");
		Scanner scn=new Scanner(System.in);
		int num=scn.nextInt();
		
		switch(num) {
		case 1:
			System.out.println("Its monday");
			break;
		case 2:
			System.out.println("Its tuesday");
			break;
		case 3:
			System.out.println("Its wednesday");
			break;
		default:
			System.out.println("Its weekend");
		}
		
		System.out.println("Enter one of the String mon,tue,wed");
		Scanner scn1=new Scanner(System.in);
		String str=scn1.next();
		
		switch(str) {
		case "mon":
			System.out.println("Its monday");
			break;
		case "tue":
			System.out.println("Its tuesday");
			break;
		case "wed":
			System.out.println("Its wednesday");
			break;
		default:
			System.out.println("Its weekend");
		}
	}

}
