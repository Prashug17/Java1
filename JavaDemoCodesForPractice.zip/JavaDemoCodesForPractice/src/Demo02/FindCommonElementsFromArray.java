package Demo02;

public class FindCommonElementsFromArray {

	public static void main(String[] args) {
		int[] arr1= {10,23,60,11,25,44,50};
		int[] arr2= {51,12,50,34,10,23,30};
		for(int a:arr1) {
			for(int b:arr2) {
				if(a==b) {
				System.out.println(a);	
				}
			}
		}
	}
}
