package Demo02;

import java.util.Scanner;

public class VowelOrConsonent {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter input");
		String ch=scanner.next();
		if(ch.equals("a")||ch.equals("e")||ch.equals("i")||ch.equals("o")||ch.equals("u")) {
			System.out.println("Vowel");
		}
		else
			System.out.println("Consonent");
	}
}
