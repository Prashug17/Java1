package Demo02;

import java.util.Scanner;

public class Average {
	public static void main(String[] args) {
		while(true) {
		System.out.println("Enter the size");
		Scanner scanner=new Scanner(System.in);
		int size=scanner.nextInt();
		
		int sum=0;
		for(int i=0;i<size;i++) {
			System.out.println("Enter the digit");
			int digit=scanner.nextInt();
			sum=sum+digit;
		}
		float average=sum/size;
		System.out.println("The average is:"+average);

		}
	}
}
