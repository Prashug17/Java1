package Demo02;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		System.out.println("Enter a string");
		Scanner scanner=new Scanner(System.in);
		String name=scanner.next();
		
		StringBuffer str=new StringBuffer(name);
		str.reverse();
		String name1=str.toString();
		if(name1.equals(name)) {
			System.out.println("palindrome");
		}
		else {
			System.out.println("Not a palindrome");
		}
	}
}
