package Demo02;

import java.util.Scanner;

public class ReverseingString {

	public static void main(String[] args) {
		String name1="";
		System.out.println("Enter a string:");
		Scanner scanner=new Scanner(System.in);
		String name=scanner.next();
		
//		StringBuffer buff=new StringBuffer(name);
//		System.out.println(buff.reverse());
		
		char[] ch=name.toCharArray();
		for(int i=name.length()-1;i>=0;i--) {
			name1=name1+ch[i];
		}
		System.out.println(name1);
	}
}
