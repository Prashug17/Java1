package Demo02;

import java.util.Scanner;

public class EvenSumOfFibonacci {

	public static void main(String[] args) {
		int a = 0, b = 1, c = 1, sum = 0;
		System.out.println("Enter range:");
		Scanner scanner = new Scanner(System.in);
		int r = scanner.nextInt();

		int[] fib = new int[r];
		int j = 0;
		for (int i = 0; i < r; i++) {
			fib[j] = a;
			j++;
			a = b;
			b = c;
			c = a + b;
		}
		for (int e : fib) {
			System.out.println(e + " ");
			if (e % 2 == 0) {
				sum = sum + e;
			}
		}
		System.out.println("The sum of even digits in the series is:" + sum);
	}
}
