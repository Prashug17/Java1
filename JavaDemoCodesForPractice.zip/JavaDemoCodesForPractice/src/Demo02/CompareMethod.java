package Demo02;

import java.util.Scanner;

public class CompareMethod {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the First number");
		int num1=scanner.nextInt();
		System.out.println("Enter the Second number");
		int num2=scanner.nextInt();
		System.out.println("The result of comparing is:"+Integer.compare(num1, num2));
		
		System.out.println("Enter the First number(Float)");
		float flt1=scanner.nextFloat();
		System.out.println("Enter the Second number(Float)");
		float flt2=scanner.nextFloat();
		System.out.println("The result of comparing is:"+Float.compare(flt1, flt2));

	}
}

//compare method returns ->
//0: if (x==y)
//-1: if (x < y)
//1: if (x > y)
