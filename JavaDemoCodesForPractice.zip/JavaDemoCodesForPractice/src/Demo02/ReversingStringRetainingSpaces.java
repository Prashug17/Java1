package Demo02;

public class ReversingStringRetainingSpaces {

	public static void main(String[] args) {
		String name="Welcome to the world of java";
		char[] ch=name.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			System.out.print(ch[i]);
		}
	}
}
