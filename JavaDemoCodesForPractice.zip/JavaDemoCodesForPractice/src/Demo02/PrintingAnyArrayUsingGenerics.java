package Demo02;

public class PrintingAnyArrayUsingGenerics {

	public <E> void printArray(E[] array){
		for(E a:array) {
			System.out.print(a+" , ");
		}
	}
	public static void main(String[] args) {
		Integer[] i= {10,2,34,54,32,96};
		String[] s= {"abc","def","ijk","lmn"};
		Float[] f= {1.11f,8.47f,63.43f,34.64f};
		Character[] c= {'a','b','c','d','e'};
		
		PrintingAnyArrayUsingGenerics print=new PrintingAnyArrayUsingGenerics();
		print.printArray(i);
		print.printArray(s);
		print.printArray(f);
		print.printArray(c);
	}

}
