package Demo02;

public class PrintingPrimeNumbers {

	public static void main(String[] args) {
		
		int low=1,high=25;
		while(low<high) {
			boolean flag=false;
			for(int i=2;i<low/2;i++) {
				if(low%i==0) {
				flag=true;
				break;
				}
			}
		if(flag==false && low!=0 && low!=1) {
			System.out.print(low+" ");
		}
		low++;
	}
	}
}
