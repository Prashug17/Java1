package Demo02;

public class GenericsCalculator<T extends Number> {
	T num1,num2;
	 
	public GenericsCalculator(T num1, T num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	
	public double add1() {
		return num1.doubleValue()+num2.doubleValue();
	}
	
	public void add() {
		System.out.println(num1.intValue()+num2.intValue());
	}
	
	public void sub() {
		System.out.println(num1.intValue()-num2.intValue());
	}
	
	public void mul() {
		System.out.println(num1.intValue()*num2.intValue());
	}
	
	public void div() {
		System.out.println(num1.intValue()/num2.intValue());
	}

	public static void main(String[] args) {
		GenericsCalculator<Integer> type1=new GenericsCalculator(20,5);
		type1.add1();
		type1.add();
		type1.sub();
		type1.mul();
		type1.div();
		
		GenericsCalculator<Float> type2=new GenericsCalculator(30.5,5.5);
		type2.add();
		type2.sub();
		type2.mul();
		type2.div();
	
	}
}
