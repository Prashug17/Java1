package stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ClassA {

	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(10,21,13,5,66);
		System.out.println(list);
		list.stream().filter(i->i%2==0).map(n->n*2).forEach(n->System.out.println(n));

	}

}
