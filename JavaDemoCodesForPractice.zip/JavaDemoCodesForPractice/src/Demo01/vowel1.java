package Demo01;

public class vowel1 {

	public static void main(String[] args) {
		
		String name="citiustech";
		char[] array=new char[10];
		char[] ch1=new char[10];
		array=name.toCharArray();
		
		for(char ch:array) {
			
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
			for(int i=0;i<ch1.length;i++) {
				ch1[i]=ch;
			}
		}
		for(int i=0;i<array.length;i++) {
			for(int j=0;i<ch1.length;j++) {
				if(array[i]!=ch1[j]) {
					System.out.println(ch1[j]);
				}
			}
		}
		
	}
		

	}

}
