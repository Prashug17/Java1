package Demo01;

import java.util.Scanner;

public class vowel {

	public static void main(String[] args) {
		String a,e,i,o,u;
		
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter input");
		String ch=scanner.next();
		
		switch (ch) {
        case "a":
        case "e":
        case "i":
        case "o":
        case "u":
            System.out.println(ch + " is vowel");
            break;
        default:
            System.out.println(ch + " is consonant");
    }
	}

}
