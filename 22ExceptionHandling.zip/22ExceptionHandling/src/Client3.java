public class Client3 {

 

    public static void main(String[] args) {
        System.out.println("Program begins..");
        try {
            System.out.println(Integer.parseInt("123"));
        }
        
//        catch(NumberFormatException e ) {
//            System.out.println(e.getMessage());
//        }
        
        finally {
            System.out.println("finally Executes");
        }

        System.out.println("Program Ends....!");
    }

 

}