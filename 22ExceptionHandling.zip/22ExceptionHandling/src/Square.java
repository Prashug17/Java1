
public class Square {

	int size;
	public int getSize() {
		return size;
	}
	public void setSize(int size) throws Exception{
		if(size<0||size>100) {
			 Exception e =new Exception("Ivalid size");
	            throw e;
		}	
		this.size = size;
	}
}

