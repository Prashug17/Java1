
public class EmployeeClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
    	emp.setAge(11);
    	System.out.println(emp.age);

	}

}
