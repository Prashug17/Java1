public class Employee {

    int age;

 

    public int getAge() {
        return age;
    }

 

    public void setAge(int age) throws  Exception   {
    	
    	System.out.println("Setting age");
        if(age<0) {
        	//RuntimeException e=new RuntimeException("age cannot negative");
        	//������������ throw e;
        	
        	
                                                                               //RuntimeException re =new RuntimeException("age connot be negative");
            Exception e =new Exception("age connot be negative");
            throw e;
            
            
        }
        this.age = age;
        System.out.println("Age set");
    }
}



// second type 
//            try {
//                throw e;
//            }catch(Exception e) {
//                System.out.println(e.getMessage());
//            }

 
