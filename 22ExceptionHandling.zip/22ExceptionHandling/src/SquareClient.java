
public class SquareClient {

	public static void main(String[] args) throws Exception  {
		// TODO Auto-generated method stub
		Square z=new Square();
        z.setSize(10);
        System.out.println(z.size);

	}

}
