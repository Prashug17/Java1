public class Client2 {

 

    public static void main(String[] args) {

        System.out.println("Program Begins");
        int[] arr= {10,20,30,40    };
        try {
        System.out.println(arr[0]);
        String s="123";
        int i=Integer.parseInt(s);
        System.out.println(++i);

        String s1="Embassy";
        System.out.println(s1.charAt(0));

        Employee e=new Employee();
        e.setAge(-10);
        
      

        }catch(ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Access Error");
            e.printStackTrace();
            System.out.println(e.getMessage());
        }catch(NumberFormatException e) {
            System.out.println("Conversion error");
            System.out.println(e.getMessage());
        }catch(Exception e ) { //generalised catch block should be always at the last
            System.out.println(e.getMessage());
        }
        System.out.println("Program Ends...!");
    }
}