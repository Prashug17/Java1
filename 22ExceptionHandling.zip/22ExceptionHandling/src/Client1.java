
public class Client1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program begins");
		
		try {
		int a,b,c;
		a=100;
		b=0;
		c=a/b;
		System.out.println(c);
		}
		catch(ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		catch(Exception e) { //to print our own error message
			System.out.println("error detected");
		}
		
		System.out.println("Program ends");
	}

}
