package com.citius.assignment.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.assignment.bean.Student;
import com.citius.assignment.db.ConnectionManager;
import com.citius.assignment.db.StudentDAO;
import com.citius.assignment.db.StudentDAOImpl;

public class AddAction extends Action {
	@Override
	 public void init() {
		 System.out.println("Adding Student");
		 System.out.println("================================");
		}
	 @Override
		public void execute() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter RollNO");
		 int rollNo=sc.nextInt();
		 System.out.println("Enter Name:");
		 String name=sc.next();
		 System.out.println("Enter mark1");
		 int mark1=sc.nextInt();
		 System.out.println("Enter mark2");
		 int mark2=sc.nextInt();
		 
		 Student stu=new Student(rollNo,name,mark1,mark2);
	     Connection con=ConnectionManager.createConnection();
	     StudentDAO dao=new StudentDAOImpl();
	     if(dao.addStudent(con, stu)==true)
	         System.out.println("student added");
	     else
	         System.out.println("student not added");
	     
	     ConnectionManager.closeConnection(con);
		}
	 

}
