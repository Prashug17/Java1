package com.citius.assignment.ui;

import java.util.Scanner;

public class MenuHandler {

	public void displayMenu() {
		String[] menuItems= {
				"Add Student",
				"Display All Student",
				"Search Student",
				"Remove Student",
				"Exit"};
		for(int i=0;i<menuItems.length;i++) {
			System.out.println((i+1)+"."+menuItems[i]);
		}
	}
	public int promptForChoice() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter your choice:");
		int choice =scanner.nextInt();
		return choice;
	}
	
	public void handleMenu() {
		while(true) {
			this.displayMenu();
			int choice = this.promptForChoice();
			
			Action action=null;
			
			switch(choice) {
	         case Actions.ADD://System.out.println("option1");
	             action =new AddAction();
	             action.go();
	         break;
	         case Actions.LISTALL://System.out.println("option2");
	             action =new ListAction();
	             action.go();
	         break;
	         case Actions.SEARCH://System.out.println("option3");
	             action =new SearchAction();
	             action.go();
	         break;
	         case Actions.REMOVE://System.out.println("option4");
	             action =new RemoveAction();
	             action.go();
	         break;
	         case Actions.EXIT:System.exit(0);
			}
		}
	}
}
