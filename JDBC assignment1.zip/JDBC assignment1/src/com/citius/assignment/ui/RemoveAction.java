package com.citius.assignment.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.assignment.bean.Student;
import com.citius.assignment.db.ConnectionManager;
import com.citius.assignment.db.StudentDAOImpl;


public class RemoveAction extends Action {
	
	@Override
    public void init() {
        System.out.println("removing student");
        System.out.println("=============");

    }

 

    @Override
    public void execute() {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter rollNo to remove:");
        int rollNo=sc.nextInt();
        
        Student stu=new Student(rollNo);
        Connection con=ConnectionManager.createConnection();
        StudentDAOImpl dao=new StudentDAOImpl();
        if(dao.removeStudent(con, stu)==true)
        	System.out.println("Student Removed");
        else
        	System.out.println("Student not Removed");

    }


}
