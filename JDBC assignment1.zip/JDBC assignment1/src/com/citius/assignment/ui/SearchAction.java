package com.citius.assignment.ui;

 

import java.sql.Connection;
import java.util.Scanner;

 

import com.citius.assignment.bean.Student;
import com.citius.assignment.db.ConnectionManager;
import com.citius.assignment.db.StudentDAOImpl;

 

public class SearchAction extends Action {

    @Override
    public void init() {
        System.out.println("searching student");
        System.out.println("=============");

 

    }

 

 

    @Override
    public void execute() {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter rollNo to search:");
        int rollNo=sc.nextInt();

        Student stu=new Student(rollNo);
        Connection con=ConnectionManager.createConnection();
        StudentDAOImpl dao=new StudentDAOImpl();
        System.out.println(dao.searchStudent(con,stu));

 

}

 

}