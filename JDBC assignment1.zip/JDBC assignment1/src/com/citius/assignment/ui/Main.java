package com.citius.assignment.ui;

public class Main {

	public static void main(String[] args) {
		MenuHandler handler=new MenuHandler();
		handler.handleMenu();

	}

}
