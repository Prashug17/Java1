package com.citius.assignment.ui;

import java.sql.Connection;

import com.citius.assignment.db.ConnectionManager;
import com.citius.assignment.db.StudentDAO;
import com.citius.assignment.db.StudentDAOImpl;

public class ListAction extends Action {
	 @Override
	 public void init() {
		  System.out.println("Displaying all students");
		  System.out.println("===============");

		    }
	 @Override
	 public void execute() {
	     Connection con=ConnectionManager.createConnection();
	     StudentDAO dao=new StudentDAOImpl();
	     System.out.println(dao.getStudents(con));
	     ConnectionManager.closeConnection(con);
	 }

}
