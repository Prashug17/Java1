package com.citius.assignment.db;

 

import java.sql.Connection;
import java.util.List;

 

import com.citius.assignment.bean.Student;

 


public interface StudentDAO {
    String INSERT_SQL="insert into student values(?,?,?,?)";
    String READ_ALL_SQL="select * from student";
    String SEARCH_SQL="select * from student where rollNo=?";
    String DELETE_SQL="delete from student where rollNo=?";

    boolean addStudent(Connection con,Student student);
    boolean removeStudent(Connection con,Student student);
    Student searchStudent(Connection con,Student student);
    List<Student> getStudents (Connection con);

 


}