package com.citius.assignment.db;

 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

 

import com.citius.assignment.bean.Student;

 


public class StudentDAOImpl implements StudentDAO {

 

    @Override
    public boolean addStudent(Connection con, Student student) {
        boolean result=false;
        try {
            PreparedStatement st=con.prepareStatement(INSERT_SQL);
            st.setInt(1, student.getRollNo());
            st.setString(2, student.getName());
            st.setInt(3, student.getMark1());
            st.setInt(4, student.getMark2());

            int r=st.executeUpdate();
            if(r==1)
                result=true;
        }catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }

 

    @Override
    public boolean removeStudent(Connection con, Student student) {
        boolean result=false;
        try {
            PreparedStatement st=con.prepareStatement(DELETE_SQL);
            st.setInt(1, student.getRollNo());

            int r=st.executeUpdate();
            if(r==1)
                result=true;
        }catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }

 

    @Override
    public Student searchStudent(Connection con, Student student) {
        Student stu=null;
        try {
            PreparedStatement st=con.prepareStatement(SEARCH_SQL);
            st.setInt(1, student.getRollNo());


            ResultSet rs=st.executeQuery();
            if(rs.next()) {
                stu=new Student(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return stu;
    }

 

    @Override
    public List<Student> getStudents(Connection con) {
        List<Student> allStu=new ArrayList<Student>();

        try {
            PreparedStatement st=con.prepareStatement(READ_ALL_SQL);
            ResultSet rs=st.executeQuery();
            while(rs.next()) {
                Student stu=new Student(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4));
                allStu.add(stu);}
            }catch(Exception e) {
                e.printStackTrace();
            }
        return allStu;
    }

 

}
