package com.citius.db;

import java.sql.Connection;
import java.util.List;

import com.citius.bean.Exam;
import com.citius.bean.Question;
import com.citius.bean.Student;
import com.citius.bean.StudentReportCard;

public interface Admin_DB {
	
	boolean createExam(Connection con , Exam exam);
	boolean deleteExam(Connection con , int exam);
	boolean updateExam(Connection con , Exam exam , String option , String columName);
	List<Exam> getAllExams(Connection con);
	List<Exam> getExamById(Connection con , int exam);
	
	boolean addStudent(Connection con , Student std);
	boolean deleteStudent(Connection con , int std);
	boolean updateStudent(Connection con , int rollNo , String choice ,String columnName );
	List<Student> getAllStudents(Connection con);
	List<Student> getStudentByRollNo(Connection con , int rollNo);
	
	List<StudentReportCard> allStudentReportCards(Connection con);
	List<StudentReportCard> singleStudentReportCard(Connection con , int id);
	
	boolean addQuestion(Connection connection , Question exam);
	boolean updateQuestion(Connection con , int exam, String columnName,String newValue);
	boolean deleteQuestion(Connection con , int exam);
	List<Question> getAllquestions(Connection con);
	

}
 