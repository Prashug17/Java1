package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetSingleStudentReportCardAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Fetching student Details");
		System.out.println("------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter student id");
		int id = sc.nextInt();
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		System.out.println(ad.singleStudentReportCard(con, id));
		
		System.out.println("enter 0 to exit");
		int choice =sc.nextInt();
		if(choice == 0) {
			AdminInterface admin = new AdminInterface();
			admin.interfaceHandler();
		}
		
	}

}
