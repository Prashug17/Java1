package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetAllQuestionAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Fetching Question Table");
		System.out.println("------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		System.out.println(ad.getAllquestions(con));
		
		System.out.println("enter 0 to go back");
		if (sc.nextInt() == 0) {
			AdminInterface admin = new AdminInterface();
			admin.interfaceHandler();
		}
		
	}

}
