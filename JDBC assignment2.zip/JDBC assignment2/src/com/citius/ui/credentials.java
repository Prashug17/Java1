package com.citius.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.citius.db.ConnectionManager;

public abstract class credentials {
	
	int id;
	String name;
	String pass;
	ConnectionManager connectionManager = new ConnectionManager();
	Connection con = connectionManager.createConnection();
	Scanner scan = new Scanner(System.in);
	abstract public void credentialCheck() throws SQLException;

}
