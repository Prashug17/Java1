package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Student;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class AddStudentAction extends Action
{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Student");
		System.out.println("-----------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Student std = new Student();
		Scanner sc = new Scanner(System.in);
//		System.out.println("enter student roll Number");
//		std.setRollNo(sc.nextInt());
		System.out.println("enter student first Name");
		std.setFirstName(sc.next());
		System.out.println("enter student last name");
		std.setLastName(sc.next());
		System.out.println("enter student gender");
		std.setGender(sc.next());
		System.out.println("enter student password");
		std.setPassword(sc.next());
		System.out.println("enter student address");
		std.setAddress(sc.next());
		System.out.println("enter student email id");
		std.setEmail(sc.next());
		System.out.println("enter student course");
		std.setCourse(sc.next());
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		AdminInterface ai = new AdminInterface();
		
		if (impl.addStudent(con, std) == true) {
			System.out.println("Student Table Created");
			ai.interfaceHandler();
		}
		
		else {
			System.out.println("Student Table not created");
			ai.interfaceHandler();
		}
	}

}
