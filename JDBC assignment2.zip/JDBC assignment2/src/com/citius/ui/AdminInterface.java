package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class AdminInterface {
	public void display() {
		String[] mainMenu = { "1. Create Exam", "2. Delete Exam", "3. Update Exam", "4. Get all Exam",
				"5. Get Exam by ID", "6. Add Student", "7. Delete Student", "8. Update Student", "9. Get All Student",
				"10. Get Student by RollNo", "11. Get Consolidated Students Report card ",
				"12. Get Single Student Report card by ID", "13. Add Question in Exam", "14. Update Question in Exam",
				"15. Delete Questions from Exam", "16. Display all Questions From Exam", "0. Logout"

		};
		for (int i = 0; i < mainMenu.length; i++) {
			System.out.println(mainMenu[i]);
		}

	}

	public int choice() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Choice");
		int choice = sc.nextInt();
		return choice;
	}

	public void interfaceHandler() {
		Connection con = ConnectionManager.createConnection();
		ConnectionManager.closeConnection(con);
		while (true) {
			display();
			int choice = this.choice();
			switch (choice) {

			case 1:
				Action act1 = new CreateExamAction();
				while (true) {
					act1.init();
					act1.execute();
				}
			case 2:
				Action act2 = new DeleteExamAction();
				while (true) {
					act2.init();
					act2.execute();
				}

			case 3:
				Action act3 = new UpdateExamAction();
				while (true) {
					act3.init();
					act3.execute();
				}

			case 4:
				Action act4 = new GetAllExamAction();
				while (true) {
					act4.init();
					act4.execute();
				}

			case 5:
				Action act5 = new GetExamByIdAction();
				while (true) {
					act5.init();
					act5.execute();
				}

			case 6:
				Action act6 = new AddStudentAction();
				while (true) {
					act6.init();
					act6.execute();
				}

			case 7:
				Action act7 = new DeleteStudentAction();
				while (true) {
					act7.init();
					act7.execute();
				}

			case 8:
				Action act8 = new UpdateStudentAction();
				while (true) {
					act8.init();
					act8.execute();
				}

			case 9:
				Action act9 = new GetAllStudentAction();
				while (true) {
					act9.init();
					act9.execute();

				}

			case 10:
				Action act10 = new GetStudentByRollNo();
				while (true) {
					act10.init();
					act10.execute();
				}

			case 11:
				Action act11 = new AllStudentReportCardAction();
				while (true) {
					act11.init();
					act11.execute();
				}

			case 12:
				Action act12 = new GetSingleStudentReportCardAction();
				while (true) {
					act12.init();
					act12.execute();
				}

			case 13:
				Action act13 = new AddQuestionAction();
				while (true) {
					act13.init();
					act13.execute();
				}

			case 14:
				Action act14 = new UpdateQuestionAction();
				while (true) {
					act14.init();
					act14.execute();
				}

			case 15:
				Action act15 = new DeleteQuestionAction();
				while (true) {
					act15.init();
					act15.execute();
				}
				
			case 16:
				Action act16 = new GetAllQuestionAction();
				while(true) {
					act16.init();
					act16.execute();
				}

			case 0:
				MenuHandler mn = new MenuHandler();
				mn.handleMenu();

			default:
				System.out.println("invalid Choice");

			}
		}
	}
}
