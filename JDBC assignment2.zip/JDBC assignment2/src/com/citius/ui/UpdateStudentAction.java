package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class UpdateStudentAction extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("updating student");
		System.out.println("------------------------");
		
	}
	
	
	void display() {
		System.out.println("1. FirstName\n"
				+ "2. LastName\n"
				+ "3. Gender\n"
				+ "4. Password\n"
				+ "5. Address\n"
				+ "6. Email\n"
				+ "7. Course\n"
				+ "0. exit");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the student roll number to be updated");
		int rollNo = sc.nextInt();
		display();
		System.out.println("enter the choice,That you want to update");
		int choice = sc.nextInt();
		String update = null ;
		String columnName = null;
		AdminInterface ad = new AdminInterface();
		
		switch(choice) {
		case 1:	System.out.println("enter new first name");
				update = sc.next();
				columnName = "stdFirstName";
				break;
		
		case 2: System.out.println("enter new last name");
				update = sc.next();
				columnName = "stdLastName";
				break;
		
		case 3: System.out.println("enter gender");
				update = sc.next();
				columnName = "stdGender";
				break;
				
		case 4: System.out.println("enter new password");
				update = sc.next();
				columnName = "stdPass";
				break;
				
		case 5: System.out.println("enter new address");
				update = sc.next();
				columnName = "stdAddress";
				break;
				
		case 6: System.out.println("enter new email");
				update = sc.next();
				columnName = "stdEmail";
				break;
		
		case 7: System.out.println("enter new course name");
				update = sc.next();
				columnName = "stdCourse";
				break;
				
		case 0 :ad.interfaceHandler();
				break;
				
		default: System.out.println("invalid choice");
		}
//		System.out.println("update = "+ update+"\t columnName = "+columnName+"\t rollno="+rollNo);
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		
		
		if(impl.updateStudent(con, rollNo,update,columnName) ==  true) {
			System.out.println("table updated");
			ad.interfaceHandler();
		}
		else {
			System.out.println("Table not updated");
		}
	}

}
