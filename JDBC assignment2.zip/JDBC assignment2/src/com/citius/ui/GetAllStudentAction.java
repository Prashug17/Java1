package com.citius.ui;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

import com.citius.bean.Student;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetAllStudentAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Displaying All the student");
		System.out.println("----------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		
		List<Student> output = impl.getAllStudents(con); 
		AdminInterface ad = new AdminInterface();
		
		System.out.println(impl.getAllStudents(con));
		
		System.out.println("press 0 to go back");
		if(sc.nextInt() == 0) {
			ad.interfaceHandler();
		}
	}

}
