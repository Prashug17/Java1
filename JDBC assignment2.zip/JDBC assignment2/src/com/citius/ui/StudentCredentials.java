package com.citius.ui;

import java.sql.SQLException;

public class StudentCredentials extends credentials{

	@Override
	public void credentialCheck() throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
