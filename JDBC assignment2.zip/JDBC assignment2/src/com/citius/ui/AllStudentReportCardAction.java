package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class AllStudentReportCardAction extends Action{

	@Override
	public void init() {
		
		System.out.println("Fetching Student Report");
		System.out.println("-------------------------------");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
		AdminDbImplementation ad = new AdminDbImplementation();
		Connection con = ConnectionManager.createConnection();
		
		System.out.println(ad.allStudentReportCards(con));
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 0 to exit");
		int choice = sc.nextInt();
		if(choice == 0) {
			System.out.println("exiting");
			AdminInterface admin = new AdminInterface();
			admin.interfaceHandler();
		}
		
		
	}

	
	
}
