package com.citius.ui;

import java.sql.SQLException;

import com.citius.db.ConnectionManager;

public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		
		MenuHandler menu = new MenuHandler();
		menu.handleMenu();
//		
//		ConnectionManager connection = new ConnectionManager();
//		System.out.println(connection.createConnection());
	}

}

