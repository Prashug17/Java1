package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class UpdateExamAction extends Action{

	private Object option;

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Updating Exam Table");
		System.out.println("--------------------------------");
		
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Exam id = new Exam();
		
			System.out.println("enter exam id to be updated or enter 0 to go back");
			id.setExamID(sc.nextInt());
			if(id.getExamID() == 0) {
				AdminInterface ai = new AdminInterface();
				ai.interfaceHandler();
			}
			
		
		
		
		
		String option = null;
		String columnName = null;
		
		String disp= "1. examName\n"
				+ "2. createdBy\n"
				+ "3. subject\n"
				+ "4. description\n"
				+ "0. Exit";
	
		
		while(true) {
			System.out.println(disp);
			System.out.println("enter choice which you want to update");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				 System.out.println("enter new exam name");
				 id.setExamName(sc.next());
				 option = id.getExamName();
				 columnName = "examName";
				break;
			case 2:
				System.out.println("enter new creator name");
				id.setCreator(sc.next());
				option = id.getCreator();
				columnName = "createdby";
				break;
			case 3:
				System.out.println("enter new subject name");
				id.setSubject(sc.next());
				option = id.getSubject();
				columnName = "subject";
				break;
			case 4:
				System.out.println("enter new description");
				id.setDescriptionString(sc.next());
				option = id.getDescriptionString();
				columnName = "description";
				break;
			case 0:AdminInterface ai = new AdminInterface();
					ai.interfaceHandler();
					break;
				

			default:
				break;
			}
			break;
		}
		
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		
		if (impl.updateExam(con, id,option,columnName) == true) {
			System.out.println("Table updated");
			this.execute();
			
		}
		else {
			System.out.println("Table not created");
		}
		ConnectionManager.closeConnection(con);
		
	}

}
