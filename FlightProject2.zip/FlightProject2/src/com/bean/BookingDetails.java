package com.bean;

public class BookingDetails {
	private int booking_id;
	private Customer customer_id;
	private Flight flight_id;
	private float booking_amount;
	private int seat_number;
	
	public BookingDetails() {
		super();
	}

	public BookingDetails(int booking_id, Customer customer_id, Flight flight_id, float booking_amount, int seat_number) {
		super();
		this.booking_id = booking_id;
		this.customer_id = customer_id;
		this.flight_id = flight_id;
		this.booking_amount = booking_amount;
		this.seat_number = seat_number;
	}

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public Customer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Customer customer_id) {
		this.customer_id = customer_id;
	}

	public Flight getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(Flight flight_id) {
		this.flight_id = flight_id;
	}

	public float getBooking_amount() {
		return booking_amount;
	}

	public void setBooking_amount(float booking_amount) {
		this.booking_amount = booking_amount;
	}

	public int getSeat_number() {
		return seat_number;
	}

	public void setSeat_number(int seat_number) {
		this.seat_number = seat_number;
	}

	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", customer_id=" + customer_id + ", flight_id=" + flight_id
				+ ", booking_amount=" + booking_amount + ", seat_number=" + seat_number + "]";
	}
	
	
	
}
