package com.bean;

import java.sql.Date;

public class Flight {
	private int flight_id; 
	private String flight_name;
	private String flight_date; 
	private String flight_source;
	private String flight_destination;
	private float flight_price;
	private float flight_duration;
	private int flight_capacity;
	
	public Flight() {
		super();
	}

	public Flight(int flight_id, String flight_name, String flight_date, String flight_source,
			String flight_destination, float flight_price, float flight_duration, int flight_capacity) {
		super();
		this.flight_id = flight_id;
		this.flight_name = flight_name;
		this.flight_date = flight_date;
		this.flight_source = flight_source;
		this.flight_destination = flight_destination;
		this.flight_price = flight_price;
		this.flight_duration = flight_duration;
		this.flight_capacity = flight_capacity;
	}

	public int getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}

	public String getFlight_name() {
		return flight_name;
	}

	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}

	public String getFlight_date() {
		return flight_date;
	}

	public void setFlight_date(String flight_date) {
		this.flight_date = flight_date;
	}

	public String getFlight_source() {
		return flight_source;
	}

	public void setFlight_source(String flight_source) {
		this.flight_source = flight_source;
	}

	public String getFlight_destination() {
		return flight_destination;
	}

	public void setFlight_destination(String flight_destination) {
		this.flight_destination = flight_destination;
	}

	public float getFlight_price() {
		return flight_price;
	}

	public void setFlight_price(float flight_price) {
		this.flight_price = flight_price;
	}

	public float getFlight_duration() {
		return flight_duration;
	}

	public void setFlight_duration(float flight_duration) {
		this.flight_duration = flight_duration;
	}

	public int getFlight_capacity() {
		return flight_capacity;
	}

	public void setFlight_capacity(int flight_capacity) {
		this.flight_capacity = flight_capacity;
	}

	@Override
	public String toString() {
		return "Flight [flight_id=" + flight_id + ", flight_name=" + flight_name + ", flight_date=" + flight_date
				+ ", flight_source=" + flight_source + ", flight_destination=" + flight_destination + ", flight_price="
				+ flight_price + ", flight_duration=" + flight_duration + ", flight_capacity=" + flight_capacity + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + flight_capacity;
		result = prime * result + ((flight_date == null) ? 0 : flight_date.hashCode());
		result = prime * result + ((flight_destination == null) ? 0 : flight_destination.hashCode());
		result = prime * result + Float.floatToIntBits(flight_duration);
		result = prime * result + flight_id;
		result = prime * result + ((flight_name == null) ? 0 : flight_name.hashCode());
		result = prime * result + Float.floatToIntBits(flight_price);
		result = prime * result + ((flight_source == null) ? 0 : flight_source.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		if (flight_capacity != other.flight_capacity)
			return false;
		if (flight_date == null) {
			if (other.flight_date != null)
				return false;
		} else if (!flight_date.equals(other.flight_date))
			return false;
		if (flight_destination == null) {
			if (other.flight_destination != null)
				return false;
		} else if (!flight_destination.equals(other.flight_destination))
			return false;
		if (Float.floatToIntBits(flight_duration) != Float.floatToIntBits(other.flight_duration))
			return false;
		if (flight_id != other.flight_id)
			return false;
		if (flight_name == null) {
			if (other.flight_name != null)
				return false;
		} else if (!flight_name.equals(other.flight_name))
			return false;
		if (Float.floatToIntBits(flight_price) != Float.floatToIntBits(other.flight_price))
			return false;
		if (flight_source == null) {
			if (other.flight_source != null)
				return false;
		} else if (!flight_source.equals(other.flight_source))
			return false;
		return true;
	}
	
	
	
}
