package com.db;

import java.sql.Connection;
import java.util.List;

import com.bean.Flight;

public interface FlightDao {
	
	String INSERT_SQL="insert into Flight values(?,?,?,?,?,?,?,?)";
	String GET_ALL_SQL="select * from Flight";
    String UPDATE_SQL="update Flight where flight_id=?";
    String DELETE_SQL="delete from Flight where flight_id=?";
	
	boolean addFlight(Connection con , Flight flight);
	boolean deleteFlight(Connection con , int flight);
	boolean updateFlight(Connection con , int flight_id , String choice ,String columnName );
	List<Flight> getAllFlights(Connection con);
	
}
