package com.db;

import java.sql.Connection;
import java.util.List;

import com.bean.Customer;
import com.bean.Flight;

public interface CustomerDao {
	String INSERT_SQL1="insert into Customer values(?,?,?,?,?,?)";
	String INSERT_SQL="insert into Flight values(?,?,?,?,?,?,?,?)";
	String GET_SQL="select * from Customer";
	String GET_ALL_SQL="select * from Flight where flight_id=?";
	
	String GET_SQL1="select * from Booking_details where booking_id=?";
	String GET_ALL_SQL1="select * from Customer";
	String UPDATE_SQL="update Flight where flight_id=?";
    String UPDATE_SQL1="update Customer where customer_id=?";
    String DELETE_SQL="delete from Booking_details where booking_id=?";
    String DELETE_SQL1="delete from Customer where customer_id=?";
    
    String INSERT_SQL2="select * from Flight where flight_date=? AND flight_source=? AND flight_destination=?";
    String INSERT_SQL3="insert into Booking_details values(?,?,?,?)";
	
	void addFlight(Connection con , Flight flight);
	boolean deleteFlight(Connection con , int flight);
	boolean updateFlight(Connection con , int flight_id , String choice ,String columnName );
	
	Customer getCustomer(Connection con , int customer);
	boolean addCustomer(Connection con , Customer customer);
	boolean deleteCustomer(Connection con , int customer);
	boolean updateCustomer(Connection con , int customer_id , String choice ,String columnName );
	Flight getFlight(Connection con);
	boolean bookingDetails(Connection con , int id);
}
