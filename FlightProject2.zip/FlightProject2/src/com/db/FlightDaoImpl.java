package com.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.Flight;
import com.ui.CustomerInterface;



public class FlightDaoImpl implements FlightDao{

	@Override
	public boolean addFlight(Connection con , Flight flight) {
		boolean result = false;
		try {
			PreparedStatement st=con.prepareStatement(INSERT_SQL);

			st.setInt(1, flight.getFlight_id());
			st.setString(2, flight.getFlight_name());
			st.setString(3, flight.getFlight_date());
			st.setString(4, flight.getFlight_source());
			st.setString(5, flight.getFlight_destination());
			st.setFloat(6, flight.getFlight_price());
			st.setFloat(7, flight.getFlight_duration());
			st.setInt(8, flight.getFlight_capacity());

			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean deleteFlight(Connection con , int flight) {
		boolean result = false;

		try {
			PreparedStatement st=con.prepareStatement(DELETE_SQL);
			st.setInt(1, flight);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean updateFlight(Connection con , int flight_id , String choice ,String columnName ) {
		
		boolean result = false;

		String query = "update Flight set " + columnName + " = ? where flight_id = (?)";
		try {
			PreparedStatement st=con.prepareStatement(query);
			st.setString(1, choice);
			st.setInt(2, flight_id);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public List<Flight> getAllFlights(Connection con) {


		List<Flight> ls = new ArrayList<Flight>();
		List<Flight> output = new ArrayList<Flight>();
		try {
			PreparedStatement st=con.prepareStatement(GET_ALL_SQL);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Flight flight = new Flight(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getFloat(6), rs.getFloat(7), rs.getInt(8));
				output.add(flight);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return output;

	}
}
