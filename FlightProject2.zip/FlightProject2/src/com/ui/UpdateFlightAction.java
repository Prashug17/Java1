package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.FlightDaoImpl;


public class UpdateFlightAction extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("updating flight");
		System.out.println("------------------------");
		
	}
	
	
	void display() {
		System.out.println("1. Flight id\n"
				+ "2. Flight name\n"
				+ "3. Date\n"
				+ "4. Source\n"
				+ "5. Destination\n"
				+ "6. Price\n"
				+ "7. Duration\n"
				+ "8. Capacity\n"
				+ "0. exit");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the flight id to be updated");
		int id = sc.nextInt();
		display();
		System.out.println("enter the choice,That you want to update");
		int choice = sc.nextInt();
		String update = null ;
		String columnName = null;
		AdminInterface ad = new AdminInterface();
		
		switch(choice) {
		case 1:	System.out.println("Enter flight id");
				update = sc.next();
				columnName = "flight_id";
				break;
		
		case 2: System.out.println("Enter flight name");
				update = sc.next();
				columnName = "flight_name";
				break;
		
		case 3: System.out.println("Enter date");
				update = sc.next();
				columnName = "flight_date";
				break;
				
		case 4: System.out.println("Enter source");
				update = sc.next();
				columnName = "flight_source";
				break;
				
		case 5: System.out.println("Enter destination");
				update = sc.next();
				columnName = "flight_destination";
				break;
				
		case 6: System.out.println("Enter price");
				update = sc.next();
				columnName = "flight_price";
				break;
		
		case 7: System.out.println("Enter duration");
				update = sc.next();
				columnName = "flight_duration";
				break;
				
		case 8: System.out.println("Enter seat capacity");
		update = sc.next();
		columnName = "flight_capacity";
		break;
				
		case 0 :ad.interfaceHandler();
				break;
				
		default: System.out.println("invalid choice");
		}

		
		Connection con = ConnectionManager.createConnection();
		FlightDaoImpl impl = new FlightDaoImpl();
		
		
		if(impl.updateFlight(con, id,update,columnName) ==  true) {
			System.out.println("Flight details updated");
			ad.interfaceHandler();
		}
		else {
			System.out.println("Details not updated");
		}
	}

}
