package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.bean.Flight;
import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;




public class GetFlightAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Displaying flight details");
		System.out.println("----------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		
		Flight output = impl.getFlight(con); 
		CustomerInterface ad = new CustomerInterface();
		
		System.out.println(impl.getFlight(con));
		
		System.out.println("press 0 to go back");
		if(sc.nextInt() == 0) {
			ad.interfaceHandler();
		}
	}

}
