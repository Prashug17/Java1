package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.FlightDaoImpl;



public class DeleteFlightAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Deleting Flight");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Flight Id To Be Deleted");
		int id = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		FlightDaoImpl impl = new FlightDaoImpl();
		AdminInterface ad = new AdminInterface();
		
		if (impl.deleteFlight(con, id) == true) {
			System.out.println("Flight deleted");
			ad.interfaceHandler();
		}
		
		else {
			System.out.println("Flight not deleted");
			ad.interfaceHandler();
		}
	}

}
