package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;



public class DeleteCustomerAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Deleting Customer");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Id To Be Deleted");
		int id = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		CustomerInterface ad = new CustomerInterface();
		
		if (impl.deleteCustomer(con, id) == true) {
			System.out.println("Customer account deleted");
			ad.interfaceHandler();
		}
		
		else {
			System.out.println("Customer account not deleted");
			ad.interfaceHandler();
		}
	}

}
