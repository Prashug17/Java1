package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;

public class AdminInterface {
	public void display() {
		String[] mainMenu = { "1. Add Flight ", "2. Delete Flight", "3. Update Flight", "4. Get all Flights", 
				"5. Get all Customers", "6. Customer section", "0. Exit"};
		for (int i = 0; i < mainMenu.length; i++) {
			System.out.println(mainMenu[i]);
		}

	}

	public int choice() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Choice");
		int choice = sc.nextInt();
		return choice;
	}

	public void interfaceHandler() {
		Connection con = ConnectionManager.createConnection();
		ConnectionManager.closeConnection(con);
		while (true) {
			display();
			int choice = this.choice();
			switch (choice) {

			case 1:
				Action act1 = new AddFlightAction();
				while (true) {
					act1.init();
					act1.execute();
				}

			case 2:
				Action act2 = new DeleteFlightAction();
				while (true) {
					act2.init();
					act2.execute();
				}

			case 3:
				Action act3 = new UpdateFlightAction();
				while (true) {
					act3.init();
					act3.execute();
				}

			case 4:
				Action act4 = new GetAllFlightAction();
				while (true) {
					act4.init();
					act4.execute();

				}
				
			case 5:
				Action act5 = new GetAllCustomerAction();
				while (true) {
					act5.init();
					act5.execute();

				}
			
			case 6:
				while (true) {
					CustomerInterface cust=new CustomerInterface();
					cust.interfaceHandler();
				}
				
			case 0:
				MenuHandler menu=new MenuHandler();
				menu.handleMenu();
				
			default:
				System.out.println("invalid Choice");

			}
		}
	}
}
