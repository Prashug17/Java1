package com.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.db.ConnectionManager;
import com.db.CustomerDaoImpl;
import com.db.FlightDaoImpl;


public class UpdateCustomerAction extends Action{

	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("updating customer");
		System.out.println("------------------------");
		
	}
	
	
	void display() {
		System.out.println("1. Customer id\n"
				+ "2. Customer name\n"
				+ "3. User name\n"
				+ "4. Password\n"
				+ "5. Email\n"
				+ "6. Phone number\n"
				+ "0. exit");
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the Customer id to update details");
		int id = sc.nextInt();
		display();
		System.out.println("enter the choice,That you want to update");
		int choice = sc.nextInt();
		String update = null ;
		String columnName = null;
		CustomerInterface ad = new CustomerInterface();
		
		switch(choice) {
		case 1:	System.out.println("Enter customer id");
				update = sc.next();
				columnName = "customer_id";
				break;
		
		case 2: System.out.println("Enter customer name");
				update = sc.next();
				columnName = "customer_name";
				break;
		
		case 3: System.out.println("Enter user name");
				update = sc.next();
				columnName = "customer_username";
				break;
				
		case 4: System.out.println("Enter Password");
				update = sc.next();
				columnName = "customer_password";
				break;
				
		case 5: System.out.println("Enter email");
				update = sc.next();
				columnName = "customer_email";
				break;
				
		case 6: System.out.println("Enter phone number");
				update = sc.next();
				columnName = "custom_phone";
				break;
				
		case 0 :ad.interfaceHandler();
				break;
				
		default: System.out.println("invalid choice");
		}

		
		Connection con = ConnectionManager.createConnection();
		CustomerDaoImpl impl = new CustomerDaoImpl();
		
		
		if(impl.updateCustomer(con, id,update,columnName) ==  true) {
			System.out.println("Customer details updated");
			ad.interfaceHandler();
		}
		else {
			System.out.println("Details not updated");
		}
	}

}
