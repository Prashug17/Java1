package com.citius.ui;

import java.sql.SQLException;

import com.citius.db.ConnectionManager;

public class Main {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		MenuHandler menu = new MenuHandler();
		menu.handleMenu();
		

//		StudentTestAction std = new StudentTestAction();
//		std.init();
//		std.execute();
	}

}
