package com.citius.ui;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citius.bean.Question;
import com.citius.bean.StudentReportCard;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetQuestionById extends Action {

	public static int examId;

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Getting Question ");
		System.out.println("--------------------");

	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("enter exam id ");
		examId = sc.nextInt();

		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();

		Integer correctAnswers = ad.getQuestionById(con);
//		System.out.println(correctAnswers);

		if (correctAnswers == null) {
			System.out.println("no questions found");
		} else {
			List<StudentReportCard> list= ad.allStudentReportCards(con);
			List<Integer> reportId = new ArrayList<Integer>();
			
			for(int i=0; i<list.size();i++) {
				reportId.add(i, list.get(i).getRollNo()); 
			}
			
			if (!(reportId.contains(StudentCredentials.rollNumber))) {
				ad.insertStudentReportCard(con, 0);
			}
			
			Connection con2 = ConnectionManager.createConnection();
			List<StudentReportCard> list1 = ad.singleStudentReportCard(con2, 			StudentCredentials.rollNumber);
			StudentReportCard obj1 = list1.get(0);
			int reportCardId = obj1.getReportCard();
//		System.out.println("correct answers = "+ correctAnswers);
			int score = ad.UpdateStdReportScore(con, correctAnswers.intValue());

			ad.insertUpdateStudentReportCard(con, score, reportCardId);
		}
		StudentInterface std = new StudentInterface();
		std.interfaceHandler();

	}

}
