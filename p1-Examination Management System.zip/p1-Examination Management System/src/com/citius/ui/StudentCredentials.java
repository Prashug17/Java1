package com.citius.ui;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentCredentials extends credentials {
	
	
	public static int rollNumber;
	@Override
	public void credentialCheck() throws SQLException {
		// TODO Auto-generated method stub

		System.out.println("Please Enter Your Registered Email:");
		name = scan.next();
		int dbPass = 0;

		System.out.println("Enter your password: ");
		int pass = scan.nextInt();

		String query = "select * from Student.student  where stdEmail = ?";
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1, name);
		ResultSet rs = st.executeQuery();
		
	
		
		while (rs.next()) {
			dbPass = rs.getInt(5);
			rollNumber = rs.getInt(1);
		}

		if (pass == dbPass) {

			StudentInterface std = new StudentInterface();
			std.interfaceHandler();
		}
		

		else {
			System.out.println("Invalid Credentials");
		}
		

	}
}
