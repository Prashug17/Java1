package com.citius.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class CreateExamAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Creating Exam Table");
		System.out.println("-----------------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		AdminInterface admin = new AdminInterface();
		Exam  exam = new Exam();
		Scanner sc = new Scanner(System.in);
		System.out.println("enter exam id");
		exam.setExamID(sc.nextInt());
		
		System.out.println("enter exam name");
		exam.setExamName(sc.next());
		
		System.out.println("enter the name of the creator");
		exam.setCreator(sc.next());
		
		System.out.println("enter subject name");
		exam.setSubject(sc.next());
		
		System.out.println("enter the description");
		exam.setDescriptionString(sc.next());
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		
		if(impl.createExam(con, exam) == true) {
			System.out.println("Table created");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
		else {
			System.out.println("Table not created");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
		
		
	}
	

}

