package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetStudentByRollNo extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Retrieving Student From DataBase");
		System.out.println("-------------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student RollNo That you want to retrieve");
		int stdRollNo = sc.nextInt();
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		
		System.out.println(ad.getStudentByRollNo(con, stdRollNo));
		ConnectionManager.closeConnection(con);
		AdminInterface admin = new AdminInterface();
		admin.interfaceHandler();
	}

}
