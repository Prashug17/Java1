package com.citius.ui;

import java.sql.Connection;
import java.util.Iterator;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class UpdateQuestionAction extends Action {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
		System.out.println("updating Questions");
		System.out.println("-----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter question id");
		int id = sc.nextInt();
		String[] display = {"1. Question\n"
				+ "2. Option1\n"
				+ "3. Option2\n"
				+ "4. Option3\n"
				+ "5. Correct Option\n"};
		
		for(int i = 0; i<display.length;i++) {
			System.out.println(display[i]);
		}
		
		String columnName = null;
		
		
		System.out.println("Enter Choice");
		int choice = sc.nextInt();
		
		switch(choice) {
		case 1: columnName = "que";
				break;
				
		case 2: columnName = "opt1";
				break;
				
		case 3: columnName = "opt2";
				break;
				
		case 4: columnName = "opt3";
				break;
				
		case 5: columnName = "correct_ans";
				break;
		default: System.out.println("invalid option");
		}
		System.out.println("enter new value");
		sc.nextLine();
		String newValue = sc.nextLine();
		
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		AdminInterface admin = new AdminInterface();
		if (ad.updateQuestion(con, id, columnName,newValue) == true) {
			System.out.println("Table Updated Succesfully");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
		else {
			System.out.println("Table couldnt be Updated");
			ConnectionManager.closeConnection(con);
		}
		
	}

}
