package com.citius.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.citius.bean.Question;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class AddQuestionAction extends Action {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Adding Question");
		System.out.println("---------------------------");

	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Question question = new Question();

		System.out.println("enter ExamId");
		question.setExamId(sc.nextInt());
		
		System.out.println("enter Question Id");
		question.setqId(sc.nextInt());
		
		sc.nextLine();

		System.out.println("enter Question");
		question.setQuestion(sc.nextLine());

		System.out.println("enter option1");
		question.setOption1(sc.nextLine());

		System.out.println("enter option2");
		question.setOption2(sc.nextLine());

		System.out.println("enter option3");
		question.setOption3(sc.nextLine());

		System.out.println("enter Correct Answer");
		question.setCorrectAnswer(sc.nextInt());

		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		AdminInterface admin = new AdminInterface();

		if (ad.addQuestion(con, question) == true) {
			System.out.println("Table Created");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
			
		} else {
			System.out.println("table not created");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
	}

}
