package com.citius.ui;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.citius.db.ConnectionManager;

public class AdminCredential extends credentials{
	
	public  void credentialCheck() throws SQLException {

		
		java.sql.Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Admin.credentialsTable ");
		
	
		System.out.println("Enter ID: ");
		id = scan.nextInt();
		
		System.out.println("Enter Username: ");
		 name = scan.next();
		 
		System.out.println("Enter Password: ");
		 pass = scan.next();
		
		while(rs.next()) {
			
			int admin_id = rs.getInt("admin_id");
			String username =rs.getString("username");	
			String password =rs.getString("password");
			
//			System.out.println(admin_id+"\t" + username+"\t" + password);
//			System.out.println("-------------------------\n"+id+"\t"+name+"\t"+pass);
			
			if(admin_id == id && username.equals(name)  && password.equals(pass)) {
				AdminInterface admin = new AdminInterface();
				ConnectionManager.closeConnection(con);
				admin.interfaceHandler();
			}
			
		}
		System.out.println("Invalid Credentials");
		ConnectionManager.closeConnection(con);
		credentialCheck();
		
	}
	

}
