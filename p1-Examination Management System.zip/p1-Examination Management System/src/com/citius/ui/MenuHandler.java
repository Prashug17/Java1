package com.citius.ui;

import java.sql.SQLException;
import java.util.Scanner;

public class MenuHandler {

	public void display() {
		String[] mainMenu = { "1. Admin", "2. Student", "0. Exit"

		};
		for (int i = 0; i < mainMenu.length; i++) {
			System.out.println(mainMenu[i]);
		}
	}

	public int choice() {
		int choice;
		Scanner menuScanner = new Scanner(System.in);
		System.out.println("Enter Your Choice: ");
		choice = menuScanner.nextInt();
		return choice;
	}

	public void handleMenu() {
		while (true) {
			display();
			int choice = this.choice();

			switch (choice) {

			case 1:
				AdminCredential admin = new AdminCredential();
				try {
					admin.credentialCheck();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			case 2:
				StudentCredentials student = new StudentCredentials();
				try {
					student.credentialCheck();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			case 3: break;
				
			default : System.out.println("Invalid Choice!");

			}
		}
	}

}
