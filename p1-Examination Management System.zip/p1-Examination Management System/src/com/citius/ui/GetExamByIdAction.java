package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetExamByIdAction extends Action {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Fetching Exam from Exam Table");
		System.out.println("---------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter exam id to be fetched");
		int examid = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		System.out.println(impl.getExamById(con, examid));
		
		System.out.println("enter 0 to exit");
		if (sc.nextInt() == 0) {
			AdminInterface ad = new AdminInterface();
			ad.interfaceHandler();
		}
		execute();
	}

}
