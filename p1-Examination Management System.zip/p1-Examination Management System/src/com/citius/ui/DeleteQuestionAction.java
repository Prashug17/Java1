package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class DeleteQuestionAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Deleting Question");
		System.out.println("-----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter question id");
		int id = sc.nextInt();
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation ad = new AdminDbImplementation();
		AdminInterface admin = new AdminInterface();
		
		if (ad.deleteQuestion(con, id)== true) {
			System.out.println("Question Table Deleted");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
		else {
			System.out.println("table not Deleted");
			ConnectionManager.closeConnection(con);
			admin.interfaceHandler();
		}
	}

}
