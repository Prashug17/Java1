package com.citius.ui;

import java.util.Scanner;

public class StudentInterface {
	

	public void interfaceHandler() {
		
		Scanner sc = new Scanner(System.in);
		while (true) {
			String display = "1. Go For Test\n" + "2. See Report Card\n" + "0. Exit";
			System.out.println(display+"\n");
			System.out.println("Enter The choice");
			int choice = sc.nextInt();

			switch (choice) {

			case 1:
				Action act1 = new StudentTestAction();
				while (true) {
					act1.init();
					act1.execute();
				}
				
			case 2:
				Action act2 = new GetSingleStudentReportCardAction();
				while(true) {
					act2.init();
					act2.execute();
					System.out.println("enter 0 to go back");
					if(sc.nextInt() == 0){
						interfaceHandler();
					}
				}
				
			case 0:
				MenuHandler menu = new MenuHandler();
				menu.handleMenu();
				
			
			default: System.out.println("Invalid Choice");
			}
		}
	}

}
