package com.citius.ui;

import java.sql.Connection;
import java.util.Scanner;

import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class DeleteStudentAction extends Action{

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Deleting Student");
		System.out.println("----------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Student Roll Number To Be Deleted");
		int rollNo = sc.nextInt();
		
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		AdminInterface ad = new AdminInterface();
		
		if (impl.deleteStudent(con, rollNo) == true) {
			System.out.println("student deleted");
			ConnectionManager.closeConnection(con);
			ad.interfaceHandler();
		}
		
		else {
			System.out.println("Student not deleted");
			ConnectionManager.closeConnection(con);
			ad.interfaceHandler();
		}
	}

}
