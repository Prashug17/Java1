package com.citius.ui;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.db.AdminDbImplementation;
import com.citius.db.ConnectionManager;

public class GetAllExamAction extends Action {
	
	
	

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Getting All Exam Details");
		System.out.println("-------------------------------");
		
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		Connection con = ConnectionManager.createConnection();
		AdminDbImplementation impl = new AdminDbImplementation();
		
		Exam exam =new Exam();
		System.out.println(impl.getAllExams(con));
		ConnectionManager.closeConnection(con);

	}

}
