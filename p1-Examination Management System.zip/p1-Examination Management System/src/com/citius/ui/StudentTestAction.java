package com.citius.ui;

import java.util.Scanner;

public class StudentTestAction extends Action {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		System.out.println("Starting Test");
		System.out.println("-----------------");

	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	
		GetAllExamAction getAllExam = new GetAllExamAction();
		getAllExam.init();
		getAllExam.execute();
		GetQuestionById question = new GetQuestionById();
		question.execute();
		
		
	}

}
