package com.citius.bean;

public class StudentReportCard {

	private int reportCardId;
	private int rollNo;
	private int score;
	private String dateOfExam;
	
	public int getReportCard() {
		return reportCardId;
	}
	public void setReportCard(int reportCard) {
		this.reportCardId = reportCard;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getDateOfExam() {
		return dateOfExam;
	}
	public void setDateOfExam(String dateOfExam) {
		this.dateOfExam = dateOfExam;
	}
	public StudentReportCard(int reportCardId, int rollNo, int score, String dateOfExam) {
		super();
		this.reportCardId = reportCardId;
		this.rollNo = rollNo;
		this.score = score;
		this.dateOfExam = dateOfExam;
	}
	public StudentReportCard() {
		super();
	}
	@Override
	public String toString() {
		return "\nStudentReportCard [reportCardId=" + reportCardId + ", rollNo=" + rollNo + ", score=" + score
				+ ", dateOfExam=" + dateOfExam + "]";
	}

	
	
		
}
