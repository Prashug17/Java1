package com.citius.bean;

public class Student {

	private int rollNo;
	private String firstName;
	private String lastName;
	private String gender;
	private String password;
	private String address;
	private String email;
	private String Course;
	
	

	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCourse() {
		return Course;
	}
	public void setCourse(String course) {
		Course = course;
	}
	
	
	public Student() {
		super();
	}
	
	public Student(int rollNo, String firstName, String lastName, String gender, String password, String address,
			String email, String course) {
		super();
		this.rollNo = rollNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.password = password;
		this.address = address;
		this.email = email;
		Course = course;
		
	}
	
	@Override
	public String toString() {
		return "\nStudent [rollNo=" + rollNo + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", password=" + password + ", address=" + address + ", email=" + email + ", Course=" + Course
				+"]";
	}
	
	
	
	
}
