package com.citius.bean;

public class Exam {
	
	private int examID;
	private String examName;
	private String creator;
	private String subject;
	private String descriptionString;
	
	public int getExamID() {
		return examID;
	}
	public void setExamID(int examID) {
		this.examID = examID;
	}
	public String getExamName() {
		return examName;
	}
	public void setExamName(String examName) {
		this.examName = examName;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDescriptionString() {
		return descriptionString;
	}
	public void setDescriptionString(String descriptionString) {
		this.descriptionString = descriptionString;
	}
	/**
	 * @param examID
	 * @param examName
	 * @param creator
	 * @param subject
	 * @param descriptionString
	 */
	public Exam(int examID, String examName, String creator, String subject, String descriptionString) {
		super();
		this.examID = examID;
		this.examName = examName;
		this.creator = creator;
		this.subject = subject;
		this.descriptionString = descriptionString;
	}
	/**
	 * 
	 */
	public Exam() {
		super();
	}
	@Override
	public String toString() {
		return "\nExam [examID=" + examID + ", examName=" + examName + ", creator=" + creator + ", subject=" + subject
				+ ", descriptionString=" + descriptionString + "]";
	}
	
	
	
	
	

}
