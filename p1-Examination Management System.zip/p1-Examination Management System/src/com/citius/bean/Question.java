package com.citius.bean;

public class Question {
	
	private int qId;
	private String question;
	private int examId;
	private String option1;
	private String option2;
	private String option3;
	private int correctAnswer;
	public Question(int qId, String question, int examId, String option1, String option2, String option3,
			int correctAnswer) {
		super();
		this.qId = qId;
		this.question = question;
		this.examId = examId;
		this.option1 = option1;
		this.option2 = option2;
		this.option3 = option3;
		this.correctAnswer = correctAnswer;
	}
	public Question() {
		super();
	}
	@Override
	public String toString() {
		return "\nQuestion [qId=" + qId + ",\nquestion=" + question + ",\nexamId=" + examId + ",\noption1=" + option1
				+ ",\noption2=" + option2 + ",\noption3=" + option3 + ",\ncorrectAnswer=" + correctAnswer + "]\n\n";
	}
	public int getqId() {
		return qId;
	}
	public void setqId(int qId) {
		this.qId = qId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	public String getOption2() {
		return option2;
	}
	public void setOption2(String option2) {
		this.option2 = option2;
	}
	public String getOption3() {
		return option3;
	}
	public void setOption3(String option3) {
		this.option3 = option3;
	}
	public int getCorrectAnswer() {
		return correctAnswer;
	}
	public void setCorrectAnswer(int correctAnswer) {
		this.correctAnswer = correctAnswer;
	}
	
	
	
	
	
	
}
