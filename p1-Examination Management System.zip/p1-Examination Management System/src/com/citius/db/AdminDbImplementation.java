package com.citius.db;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.citius.bean.Exam;
import com.citius.bean.Question;
import com.citius.bean.Student;
import com.citius.bean.StudentReportCard;
import com.citius.ui.CreateExamAction;
import com.citius.ui.GetQuestionById;
import com.citius.ui.StudentCredentials;

public class AdminDbImplementation implements Admin_DB {

	@Override
	public boolean createExam(Connection con, Exam exam) {
		boolean result = false;
		try {

			String query = "insert into Student.exam (examName, createdby , subject , description) values(?,?,?,?) ";

			PreparedStatement st = con.prepareStatement(query);

			st.setString(1, exam.getExamName());
			st.setString(2, exam.getCreator());
			st.setString(3, exam.getSubject());
			st.setString(4, exam.getDescriptionString());

			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean deleteExam(Connection con, int exam) {
		// TODO Auto-generated method stub
		boolean result = false;

		try {

			String query = "delete from Student.exam where examID = ?";
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, exam);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean updateExam(Connection con, Exam exam, String option, String columName) {
		// TODO Auto-generated method stub
		boolean result = false;
		try {
			String query = "update Student.exam set " + columName + " = ? where examID = (?) ";
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, option);
			st.setInt(2, exam.getExamID());
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;

	}

	@Override
	public List<Exam> getAllExams(Connection con) {
		// TODO Auto-generated method stub
		List<Exam> storage = new ArrayList<Exam>();
		String query = "select * from Student.exam";
		try {
			PreparedStatement st = con.prepareStatement(query);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				Exam ex = new Exam(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				storage.add(ex);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return storage;
	}

	@Override
	public List<Exam> getExamById(Connection con, int exam) {
		// TODO Auto-generated method stub
		List<Exam> storage = new ArrayList<Exam>();
		String query = "Select * from Student.exam where examID = ?";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, exam);
			ResultSet rs = st.executeQuery();
			rs.next();
			Exam ex = new Exam();
			ex.setExamID(rs.getInt(1));
			ex.setExamName(rs.getString(2));
			ex.setCreator(rs.getString(3));
			ex.setSubject(rs.getString(4));
			ex.setDescriptionString(rs.getString(5));

			storage.add(ex);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return storage;
	}

	@Override
	public boolean addStudent(Connection con, Student std) {
		// TODO Auto-generated method stub
		boolean result = false;
		String query = "insert into Student.student values (?,?,?,?,?,?,?)";
		try {
			PreparedStatement st = con.prepareStatement(query);

			st.setString(1, std.getFirstName());
			st.setString(2, std.getLastName());
			st.setString(3, std.getGender());
			st.setString(4, std.getPassword());
			st.setString(5, std.getAddress());
			st.setString(6, std.getEmail());
			st.setString(7, std.getCourse());

			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean deleteStudent(Connection con, int std) {
		// TODO Auto-generated method stub
		boolean result = false;
		String query = "delete from Student.student where stdRollNo = ?";

		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, std);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public boolean updateStudent(Connection con, int rollNo, String updation, String columnName) {
		// TODO Auto-generated method stub
		boolean result = false;

		String query = "update Student.student set " + columnName + " = ? where stdRollNo = (?)";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, updation);
			st.setInt(2, rollNo);
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = false;
		}

		return result;
	}

	@Override
	public List<Student> getAllStudents(Connection con) {
		// TODO Auto-generated method stub
		String query = "select * from Student.student";

		List<Student> ls = new ArrayList<Student>();
		List<Student> output = new ArrayList<Student>();
		PreparedStatement st;
		try {
			st = con.prepareStatement(query);
			ResultSet rs = st.executeQuery();

			while (rs.next()) {
				Student std = new Student(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
				output.add(std);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return output;
	}

	@Override
	public List<Student> getStudentByRollNo(Connection con, int rollNo) {
		// TODO Auto-generated method stub
		Student std = new Student();
		List<Student> stdList = new ArrayList<Student>();
		String query = "select * from Student.student where stdRollNo = ?";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, rollNo);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				std.setRollNo(rs.getInt(1));
				std.setFirstName(rs.getString(2));
				std.setLastName(rs.getString(3));
				std.setGender(rs.getString(4));
				std.setPassword(rs.getString(5));
				std.setAddress(rs.getString(6));
				std.setEmail(rs.getString(7));
				std.setCourse(rs.getString(8));

				stdList.add(std);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return stdList;
	}

	@Override
	public List<StudentReportCard> allStudentReportCards(Connection con) {
		// TODO Auto-generated method stub
		List<StudentReportCard> list = new ArrayList<StudentReportCard>();
		String query = "Select * from Exam.reportCard";

		try {
			PreparedStatement st = con.prepareStatement(query);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				StudentReportCard src = new StudentReportCard(rs.getInt(1), rs.getInt(2), rs.getInt(3),
						rs.getString(4));
				list.add(src);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<StudentReportCard> singleStudentReportCard(Connection con, int id) {
		// TODO Auto-generated method stub
		List<StudentReportCard> std = new ArrayList<StudentReportCard>();
		String query = "select * from Exam.reportCard where studentRollNumber = ? ";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				StudentReportCard src = new StudentReportCard(rs.getInt(1), rs.getInt(2), rs.getInt(3),
						rs.getString(4));
				std.add(src);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return std;
	}

	@Override
	public boolean addQuestion(Connection connection, Question exam) {
		// TODO Auto-generated method stub
		boolean result = false;
		String query = "insert into Exam.QuestionTable values (?,?,?,?,?,?,?)";
		try {
			PreparedStatement st = connection.prepareStatement(query);
			st.setInt(1, exam.getqId());
			st.setString(2, exam.getQuestion());
			st.setInt(3, exam.getExamId());
			st.setString(4, exam.getOption1());
			st.setString(5, exam.getOption2());
			st.setString(6, exam.getOption3());
			st.setInt(7, exam.getCorrectAnswer());
			int r = st.executeUpdate();
			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean updateQuestion(Connection con, int id, String columName, String newValue) {
		// TODO Auto-generated method stub
		boolean result = false;
		String query = "update Exam.QuestionTable set " + columName + " = ? where q_id = (?) ";

		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setString(1, newValue);
			st.setInt(2, id);
			int r = st.executeUpdate();

			if (r == 1) {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean deleteQuestion(Connection con, int exam) {
		// TODO Auto-generated method stub
		boolean result = false;
		String query = "delete from Exam.QuestionTable where q_id = ?";

		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, exam);
			int r = st.executeUpdate();

			if (r == 1) {
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public List<Question> getAllquestions(Connection con) {
		// TODO Auto-generated method stub
		List<Question> list = new ArrayList<Question>();
		String query = "select * from Exam.QuestionTable";

		try {
			PreparedStatement st = con.prepareStatement(query);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				Question output = new Question(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getInt(7));
				list.add(output);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	public Integer getQuestionById(Connection con) {

		Integer correctAnswers = 0;
		Question ques = new Question();
		String query = "select * from Exam.QuestionTable where examID = ?";
		try {
			PreparedStatement st = con.prepareStatement(query);
			st.setInt(1, GetQuestionById.examId);
			ResultSet rs = st.executeQuery();

			if (rs.next()) {

				do {

					ques.setQuestion(rs.getString(2));
					ques.setOption1(rs.getString(4));
					ques.setOption2(rs.getString(5));
					ques.setOption3(rs.getString(6));

					System.out.println("\nQuestion \n" + ques.getQuestion() + "\n\noption1=" + ques.getOption1()
							+ "\noption2=" + ques.getOption2() + "\noption3=" + ques.getOption3() + "\n");

					Scanner sc = new Scanner(System.in);
					System.out.println("Enter the Answer in Number");
					int answer = sc.nextInt();
					if (answer == rs.getInt(7)) {
						correctAnswers++;
					}

				} while (rs.next());
			}

			else {
				return null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return correctAnswers;

	}

	public int UpdateStdReportScore(Connection con, int correctAnswer) {
		int rollNumber = StudentCredentials.rollNumber;
		int dbScore = 0;

		StudentReportCard obj = null;

		String getQuery = "select * from Exam.reportCard where studentRollNumber = ?";

		List<StudentReportCard> stdCards = singleStudentReportCard(con, StudentCredentials.rollNumber);

		obj = stdCards.get(0);
		dbScore = obj.getScore() + (correctAnswer * 10);

//		 dbScore =Integer.parseInt(stdCards.get(1).toString());

		return dbScore;

	}

	public void insertStudentReportCard(Connection con, int score) {


		String Updatequery = "insert into Exam.reportCard values ((?),(?),GETDATE())";
//		System.out.println(score);
//		System.out.println(StudentCredentials.rollNumber);

		try {
			PreparedStatement st = con.prepareStatement(Updatequery);
			st.setInt(1, StudentCredentials.rollNumber);
			st.setInt(2, score);
			int r = st.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void insertUpdateStudentReportCard(Connection con, int score, int reportCardId) {
	
		
//		if(reportId.contains(reportCardId)) {
//			insertStudentReportCard(con, score);
//		}
		

		
		String Updatequery = "update  Exam.reportCard  set score = ? where reportCardId = (?) ";
//		System.out.println(score);
//		System.out.println(StudentCredentials.rollNumber);

		try {
			PreparedStatement st = con.prepareStatement(Updatequery);
			st.setInt(1, score);
			st.setInt(2, reportCardId);
			int r = st.executeUpdate();
			System.out.println("Exam Finished");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		
	}

}
