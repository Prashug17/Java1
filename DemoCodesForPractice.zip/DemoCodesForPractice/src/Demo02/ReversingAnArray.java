package Demo02;

public class ReversingAnArray {

	public static void main(String[] args) {
		String[] names= {"abc","def","ijk","lmn"};
		
		for(int i=names.length-1;i>=0;i--) {
			System.out.print(names[i]+" ");
		}
	}
}
