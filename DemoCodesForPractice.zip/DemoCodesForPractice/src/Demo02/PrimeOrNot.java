package Demo02;

import java.util.Scanner;

public class PrimeOrNot {

	public static void main(String[] args) {
		System.out.println("Enter the number:");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();
		
		boolean flag=false;
		for(int i=2;i<num/2;++i) {
			if(num%i==0) {
				flag=true;
				break;
			}
		}
		if(flag==true && num!=0 &&num!=1) {
			System.out.println("Number is not a prime");
		}
		else {
			System.out.println("Number is prime");
		}
	}

}
