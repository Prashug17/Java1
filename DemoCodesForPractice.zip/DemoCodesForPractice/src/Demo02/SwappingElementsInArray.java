package Demo02;

import java.util.Arrays;

//swapping first and last elements of an array
public class SwappingElementsInArray {

	public static void main(String[] args) {
		int[] arr= {10,20,30,40,50};
		int first=arr[0];
		int last=arr[arr.length-1];
		
		arr[0]=last;
		arr[arr.length-1]=first;
		for(int i:arr) {
			System.out.print(i+" ");
		}
	}

}
