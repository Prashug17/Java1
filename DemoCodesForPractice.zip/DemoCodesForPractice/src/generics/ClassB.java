package generics;

public class ClassB<T extends Number> {
	T num1;
	T num2;
	public ClassB(T num1, T num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
	
	public T add() {
		if(num1 instanceof Integer && num2 instanceof Integer) {
			return (T) (Object) (num1.intValue()+num2.intValue());
		}
		else if(num1 instanceof Double && num2 instanceof Double) {
			return (T) (Object) (num1.doubleValue()+num2.doubleValue());
		}
		else {
			throw new UnsupportedOperationException("Unsupported data type");
		}
		
	}
}
