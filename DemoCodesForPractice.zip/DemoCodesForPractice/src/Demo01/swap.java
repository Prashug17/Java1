package Demo01;
import java.util.Scanner;

public class swap {

	public static void main(String[] args) {
		int a;
		int b;
		int temp;
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter num1");
		int n1=scanner.nextInt();
		System.out.println("Enter num2");
		int n2=scanner.nextInt();
		
		temp=n1;
		n1=n2;
		n2=temp;
		
		System.out.println(n1+" "+n2);

	}

}
