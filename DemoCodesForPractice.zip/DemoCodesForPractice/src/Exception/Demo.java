package Exception;

public class Demo {

	public static void main(String[] args) {
		TestClass test = new TestClass();
		try {
			test.Validate(20);
		} catch (ExceptionHandle e) {
			
			System.out.println(e);
		}
	}

}
