package Exception;

public class TestClass {

	public void Validate(int age) throws ExceptionHandle {
		if (age<18) {
			throw new ExceptionHandle("Invalid age");
		}
		else {
			System.out.println("Welcome");
		}
	}
}
