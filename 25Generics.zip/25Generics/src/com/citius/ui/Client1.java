package com.citius.ui;

import com.citius.bean.ByteStackImpl;
import com.citius.bean.Circle;
import com.citius.bean.CircleStackImpl;
import com.citius.bean.IntStackImpl;
import com.citius.bean.ObjectStackImpl;
import com.citius.bean.QueueImpl;

public class Client1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteStackImpl impl1=new ByteStackImpl();
		
		impl1.push((byte)10);
		impl1.push((byte)20);
		byte v1=30;
		impl1.push(v1);
		
		System.out.println(impl1.pop());
		System.out.println(impl1.pop());
		System.out.println(impl1.pop());
		
		IntStackImpl impl2=new IntStackImpl();
		
		impl2.push((int)15);
		impl2.push((int)25);
		int v2=35;
		impl2.push(v2);
		
		System.out.println(impl2.pop());
		System.out.println(impl2.pop());
		System.out.println(impl2.pop());
		
		
		CircleStackImpl impl3=new CircleStackImpl();
		
		impl3.push(new Circle(45));
		impl3.push(new Circle(55));
		Circle c=new Circle(65);
		impl3.push(c);
		
		
		System.out.println(impl3.pop());
		System.out.println(impl3.pop());
		System.out.println(impl3.pop());
		
		ObjectStackImpl<Integer> impl4=new ObjectStackImpl<>();
		impl4.push(new Integer(90));
		impl4.push(new Integer(100));
		impl4.push(new Integer(200));
		
//		System.out.println(impl4.pop());
//		System.out.println(impl4.pop());
//		System.out.println(impl4.pop());
		
		Integer obj1=impl4.pop();
		System.out.println(obj1.doubleValue());
		
		Integer obj2=impl4.pop();
		System.out.println(obj2.doubleValue());
		
		Integer obj3=impl4.pop();
		System.out.println(obj3.doubleValue());
		
		
//		ObjectStackImpl impl4=new ObjectStackImpl();
//		impl4.push("Hello");
//		impl4.push(new Integer(30));
//		impl4.push(new Circle(20));
//		impl4.push(new Long(80));
//		impl4.push(new StringBuffer("Welcome"));
		
//		System.out.println(impl4.pop());
//		System.out.println(impl4.pop());
//		System.out.println(impl4.pop());
//		System.out.println(impl4.pop());
		
		
//		StringBuffer obj1=(StringBuffer)impl4.pop();
//		obj1.append("to ETV");
//		
//		Long obj2=(Long) impl4.pop();
//		System.out.println(obj2.intValue());
		
//		Object obj=impl4.pop();
//		if(obj instanceof StringBuffer) {
//			StringBuffer temp=(StringBuffer) obj;
//			temp.append("to ETV");
//			System.out.println(temp);
//		}
//		
//		if(obj instanceof Circle) {
//			Circle temp=(Circle) obj;
//			System.out.println(temp);
//		}
//		
//		if(obj instanceof String) {
//			String temp=(String) obj;
//			System.out.println(temp);
//		}
//		
//		if(obj instanceof Long) {
//			Long temp=(Long) obj;
//			System.out.println(temp);
//		}
			
	QueueImpl<Circle> impl6=new QueueImpl<>();	
	impl6.add(new Circle(10));
	Circle c1=impl6.remove();
	}

}
