package com.citius.bean;

public class GeneralList<T> implements List<T>{
//	Object[] arr=new Object[10];
	
//	@Override
//	public void add(T obj) {
//		// TODO Auto-generated method stub
//		for(int i=0;i<arr.length;i++) {
//			
//			arr[i]=obj;
//			
//			if(arr.length>10) {
//				Object[] copy = new Object[arr.length + 1];
//				 copy[i]=arr;
//			}
//			else {
//				arr[i]=obj;
//			}
//			return(T) copy;
//		}
//		return(T) arr;
//	}

	int size;
    int index;
    Object[] arr= new Object[10];
    
    @Override
    public void add(T obj) {
        arr[index]=obj;
        ++index;
        System.out.println(obj+" Added");
    }
	
	@Override
	public void insert(int position, T obj) {
		arr[position]=obj;
        index++;    
        System.out.println("inserted "+obj+" At Position "+position);
		
	}

	@Override
	public T remove(int position) {
		 return (T) arr[position];
	}

}
