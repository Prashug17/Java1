package com.citius.bean;

public class ListClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GeneralList<Circle> impl7 = new GeneralList();
        impl7.add(new Circle(500));
        impl7.insert(1, new Circle(600));
        impl7.insert(2, new Circle(700));
        impl7.add(new Circle(800));
        System.out.println(impl7.remove(3));
        System.out.println(impl7.remove(2));
//        System.out.println(impl6.remove(0));

	}

}
