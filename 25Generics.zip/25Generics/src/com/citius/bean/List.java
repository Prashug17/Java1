package com.citius.bean;

public interface List<T> {
	void add(T obj);
	void insert(int position,T obj);
	T remove(int position);
}
