package com.citius.bean;

public class CircleStackImpl {
	Circle[] arr;
	int index;
	
	public CircleStackImpl(){
		arr=new Circle[10];
	}
	
	public void push(Circle b) {
		arr[index++]=b;
	}
	
	public Circle pop() {
		return arr[--index];
	}
}
