package com.citius.bean;

public class Circle {

		int radius;

		public Circle(int radius) {
			super();
			this.radius = radius;
		}

		@Override
		public String toString() {
			return "Circle [radius=" + radius + "]";
		}
		
		
}
