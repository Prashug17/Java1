package com.citius.bean;

public class ObjectStackImpl<T> {
	Object[] arr;
    int index;

 

    public ObjectStackImpl() {
        arr = new Object[10];
    }

    public void push(T b) {
        arr[index++]=b;
    }

    public T pop() {
        return (T) arr[--index];
    }
}
