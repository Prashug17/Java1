package com.citius.bean;

public class QueueImpl<T> implements Queue<T>{
//public class QueueImpl implements Queue<String>{

	@Override
	public void add(T obj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T remove() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
