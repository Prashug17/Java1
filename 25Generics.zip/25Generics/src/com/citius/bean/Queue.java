package com.citius.bean;

public interface Queue<T> {
	void add(T obj);
	T remove();
	
}
