
public class ContactClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Contact obj1=Contact.getInstance();
		System.out.println(obj1);
		obj1.getDetails();
		
		Contact obj2=Contact.getInstance();
		System.out.println(obj2);
		obj2.getDetails();
	}

}

