/*A singleton class is a class that can have only one object (an instance of the class) at a time. 
The primary purpose of a Singleton class is to restrict the limit of the number of object creation 
to only one.*/

public class Contact {
	
	private static Contact address=null;
	
	private Contact() {
		
	}
	
	public static Contact getInstance() {
		if(address==null) 
		{
			address=new Contact();
		}
		return address;
	}

	public void getDetails() {
		System.out.println("The details are printed");
	}
}
