
public class Array {
	public static void main(String[] args) {
	int[] array = { 50, 6, 60, 70, 80, 90, 9, 150, 2, 35 };
	int max = 0;
	int secondmax = 0;

	for (int x = 0; x < array.length; x++) {
	    if (array[x] > max)
	        max = array[x];
	    if (array[x] > secondmax && secondmax != max)
	        secondmax = array[x];
	}
	System.out.println("Second Highest number in the array is: " + secondmax);
}
}


